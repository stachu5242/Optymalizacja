#include <stdio.h>
#include <math.h>


float
x_pow_y(x, y)
    float           x;
    int             y;
{
    int             i;
    float           tot = 1.0;

    for (i = 0; i < y; i++)
	tot = tot * x;
    return (tot);
}


main()
{
    int             i;
    double          Q = 0.1, Q1;
    int pop_size = 70;
	float r;
    /* Q, Q(1-Q)^1, Q(1-Q)^2 ... Q(1-Q)^n */
    Q1 = Q / (1 - x_pow_y(1 - Q, pop_size));
    for (i = 1; i <= pop_size; i++)
{
	r = Q1 * x_pow_y(1 - Q, i - 1);
	printf("%f\n", r);
}
}


