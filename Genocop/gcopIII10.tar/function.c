/****************************************************************************
***
***
*** FUNCTION.C
***
*** NOTE:
***
*** This is where you enter the objective function(s).  Choose
*** unique case numbers and remember to insert the 'break;' statement at
*** the end of each case.  Also, mind the semicolon after each function
*** line.  All functions are of the form X[0] = f(X[1], X[2],...,X[n]);
***
*** The core data structure variable EVOLDATA ev (see the file GENOCOP.H)
*** available at this point.  You may access any of the variables
*** in this structure, but DO NOT CHANGE THEM or the code won't
*** work.
***
*** If you wish to use additional variables, they MUST be declared
*** in the file EVALFUNC.C, in the function in which this file
*** (FUNCTION.C) is physically inserted during compilation time.
*** If you're not sure what this means, you probably shouldn't try it.
***
*** Also, some compilers won't flag declarations inside included files
*** as an error (esp. C++ compilers), but the CODE WON'T WORK.
***
***	Copyright (C) 1995, Girish Nazhiyath, Zbigniew Michalewicz.
***	All rights reserved.
***	Comments/suggestions to zbyszek@uncc.edu, gnazhiya@uncc.edu.
***
***
***************************************************************************/	


		case 1: X[0] = (X[1] - 2.0)*(X[1] - 2.0) +
						(X[2] -1.0)*(X[2] - 1.0);
				break;


		case 2:
				X[0] = X[1]*X[1] + X[2]*X[2];
				break;

		case 3:
				X[0] = (1.0 - X[1])*(1.0 - X[1]);
				break;



/******* END OF FILE ******************************************************/


