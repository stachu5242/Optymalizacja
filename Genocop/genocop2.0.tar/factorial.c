#include "genocop.h"

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   factorial()                                  */
/*                                                                              */
/*           SYNOPSIS          :   int factorial(a,a_inverse,n)                 */
/*                                                                              */
/*           DESCRIPTION       :   This function returns the factorial of a     */
/*                                  given integer                               */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   p_equalities()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/




unsigned long factorial(n)
int n;
{
  unsigned long  tot = 1;

  if(n < 0)
    {
      printf("\n\n  Negative factorial in routine FACTORIAL \n\n");
      exit(0);
    }

  while(n > 1)
    tot = tot * n--;

  return(tot);
}

