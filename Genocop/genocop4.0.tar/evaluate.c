#include "genocop.h"

#if DOS_SYS
extern FILE *input,*output;
extern int test_num;
extern unsigned long count_gener;
#endif

/* Cummulative probability on crossover */
/* Random probability on mutation       */
/* NO multiple hits per agent possible  */


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   optimization()                               */
/*                                                                              */
/*           SYNOPSIS          :   void optimization(X,x1,x2,fin_mat,rc,tot_eq) */
/*                                                                              */
/*           DESCRIPTION       :   This procedure initializes the population    */
/*                                  with the values X passed from main, and     */
/*                                  evaluates them.  After assigning weight     */
/*                                  for each member of the populaiton, a group  */
/*                                  of them are chosen to reproduce and a group */
/*                                  is chosen to die.  Genetic operators are    */
/*                                  applied and a new generation is produced    */
/*                                  to replace the members that died.  This     */
/*                                  cycle continues for the number of times,    */
/*                                  user specifies in the input file            */
/*                                                                              */
/*           FUNCTIONS CALLED  :   assign_probab(),  evaluate(),                           */
/*                                 find_cum_probab(), find_live_die(),                          */
/*                                 find_parent(), ivector(),                              */
/*                                 matrix(), oper1(),                                   */
/*                                 oper2(), oper3(),                                   */
/*                                 oper4(), oper5(),                                    */
/*                                 oper6(),  print_matrix(),                                   */
/*                                 print_population(), sort(),                         */
/*                                 vector().                                    */
/*                                                                              */
/*           CALLING FUNCITONS :   main()                                       */
/*           AUTHOR            :   Sunil Reddy Talusani                      */
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void optimization(VECTOR X,IVECTOR x1,IVECTOR x2,MATRIX fin_mat,INDEX rc,int tot_eq,VECTOR a1_b,int tot_var,IVECTOR intarr)
{
  MATRIX new_genera,   /*Temporary storage for the new generation*/
         population,   /*Population of x2 variables*/
         print_pop,
         temp,nepw;

  VECTOR probab,       /*Probability of agents to die or live*/
         cum_probab,   /*Cumilative probability of agents*/
         t_vec,
	 init_vec,
	 prev_vec,
	 best_vec,best_gen;

  IVECTOR live,
          die;


  unsigned long generations,
	counter=0,
	numofgen,
	epoch,init_epoch;    /*Total number of Generations*/
  unsigned long count_gener= 1;
/*Counter to keep track of the number of generations*/
  unsigned long peak_cnt;

  int pop_size,              /*Population size*/
      MinMax,                /*Minimization or Maximization problem 0 or 1 */
      init_val,				 /*Single or multiple point init. population? */
      P,                     /*Total number of agents chosen to reproduce*/
      P1,                    /*Number of parents for each of the 5 operators*/
      P2,
      P3,
      P4,
      P5,
      P6,
      P7,
      j1,
      j2,
      j3,
      j4,
      j5,
      j6,
      j7,
      oper,
      B,                     /*Parameter for the 3rd operator - nonuniform mutation*/
      STEP,                  /*Parameter for the 5th operator - simple arithmetical crossover*/
      x2_vari = rc.c-2,
      first,                 /*Index of the parent to mutate*/
      first_live,            /*Index of the two parents for crossover parents*/
      second_live,
      first_die,             /*Index of the two parents for crossover death*/
      second_die,
      tot,                   /*total number of chosen parents not used*/
      i,
      j,
      k,l=1,
      dup_count /* replication count */
      ;	

  float Q,                   /*Probability of the best agent*/
        A,                   /*Parameter for the 4th operator - whole arithmetical cross over*/
        Teval,               /*Evaluation of the best agent*/
        initial_val;         /*Initial value of the population */
  float peak_val,	     /*Variables for management of epochs.*/
	prev_change_at,delta,
	ngen_back,ngen,kk;
  int x,y;

  FLAG  same;
  FLAG  _PROGEND;
  FLAG  condit;
  FLAG  condit1;    /*check condition to see if the newly created vectors*/ 
  FLAG  condit2;    /*satisfies the set of constraints                   */
  FLAG  condit3; 
  FLAG  condit6;
  int CHANGES=0;
  int TYPE;
  char response_char;  
/*  float**new;*/
count_gener=1;

	rem();
  fscanf(input,"%d",&pop_size);
	rem();
  fscanf(input,"%u",&generations);
	rem();
  fscanf(input,"%d %d %d %d %d %d %d",&P1,&P2,&P3,&P4,&P5,&P6,&P7);
	rem();
  fscanf(input,"%f ",&Q);
	rem();
  fscanf(input,"%d ",&MinMax);
	rem();
  fscanf(input,"%d ",&init_val);
	rem();
  fscanf(input,"%d ",&B);
	rem();
  fscanf(input,"%d ",&STEP);
	rem();
  fscanf(input,"%d ",&TYPE);
	rem();
  fscanf(input,"%u ",&epoch);
	init_epoch=epoch;
 	rem();
  fscanf(input,"%u ",&numofgen);
	 rem();
  fscanf(input,"%f ",&delta);
	rem();
  fscanf(input,"%d ",&test_num);
if(TYPE == 1)
	if((epoch<=0)||(epoch>=generations))
	{printf("Error : While entering fixed epoch size in input file.\n");
	exit(0);
	}
if(TYPE==0)
	if((numofgen<=0)||(numofgen>=generations))
	{printf("Error : While entering variable epoch size in input file.\n");
	exit(0);	
	}

printf("\nThe value of test_num is  :%d\n",test_num);

fclose(input);
  fprintf(output,"\n\n");
  fprintf(output,"Test case number      : %d\n", test_num);
  fprintf(output,"Number of operators   : %d  %d  %d  %d  %d  %d  %d\n", P1, P2, P3, P4, P5, P6, P7);
  fprintf(output,"Number of generations : %lu\n",generations);
  fprintf(output,"Population size       : %d\n", pop_size);
  fprintf(output,"Parameter B           : %d\n", B);
  fprintf(output,"Parameter Q           : %f\n", Q);


  /*P is the total number of parents needed for applying all the operators*/
  P = P1 + P2 + P3 + P4 + P5 + P6 + P7;
  if(P > pop_size)
    {
      printf("The total number of operators greater than population\n");
      fprintf(output,"The total number of operators greater than population\n");
      fclose(output);
      exit(1);
    }

  peak_val = 0;
  peak_cnt = 0;

  /*Space allocation for all the vectors and matrices involved*/
  population = matrix(0,pop_size,0,x2_vari+1);
   new_genera = matrix(0,pop_size,0,x2_vari+1);
  temp       = matrix(1,2,1,x2_vari);
  best_gen   = vector(0,generations);
  t_vec      = vector(1,x2_vari);
  init_vec   = vector(0,x2_vari+1);
  prev_vec   = vector(0,x2_vari+1);
  best_vec   = vector(0,x2_vari+1);
  cum_probab = vector(1,pop_size);
  live       = ivector(1,pop_size);
  die        = ivector(1,pop_size);

  /*Initial population with all identical agents, whose values were got randomly*/
  if (init_val == 1)
  {

  fprintf(output, "\n\nUSING SINGLE POINT INITIAL POPULATION...\n\n");
        _PROGEND = initialize_x2(fin_mat,rc,x1,x2,tot_eq,X,a1_b,intarr);

  	for(j=1; j<=pop_size; j++)
  	{
  	  for(i=1; i<=x2_vari; i++)
          {
        	population[j][i] = X[x2[i]];
        	population[j][x2_vari+1] = 0;
      	  }
     	  population[j][0] = evaluate(X);
  	}
  fprintf(output,"\nThe initial point of the population is\n");
	print_vector(X,1,tot_eq+x2_vari);
  } 	/* end of if init_val == 1*/

  else
  {

  fprintf(output, "\n\nUSING MULTIPLE POINT INITIAL POPULATION...\n\n");
     	j = 0;
     	while (j<=pop_size)
     	{
       		_PROGEND = initialize_x2(fin_mat,rc,x1,x2,tot_eq,X,a1_b,intarr);
       		if (_PROGEND == TRUE)
       		{
         	for(i=1; i<=x2_vari; i++)
         	{
           		population[j][i] = X[x2[i]];
           		population[j][x2_vari+1] = 0;
         	}
         	j++;
       }
       else 
       {
      printf("Do you wish to include/replicate this vector in the population? (y/n)");
      fflush(stdin);
      response_char = getchar();
      fflush(stdin);
      if (response_char=='Y' || response_char=='y')
      {
        do{ 
	      	printf("How many copies (min. 1, max. %d) :", pop_size-j+1);        	
		  	scanf("%d", &dup_count);
		if ((dup_count < 1) || (dup_count > (pop_size-j+1)))
  	printf("\nInvalid entry.  Must be in the range 1 to %d\n",pop_size-j+1);
	  } while ((dup_count < 1) || (dup_count > (pop_size-j+1)));
  	
  	
       	for (k=1; k<=dup_count; k++)
      	{
      	    for(i=1; i<=x2_vari; i++) {
	      		population[j][i] = X[x2[i]];
	      		population[j][x2_vari+1] = 0;
	      	}
      		j++;
      	} /* end of for dup_count.... */
      		
      } /* end of if response_char...... */
    }    /* end of if _PROGEND...else.............. */
   }/* end of do loop */
  }   /* end of if in_val.....else.................*/ 


/*********** eval. and sort first generation *************************/

      for(i=1; i<=pop_size; i++)
        {
          /*if (population[i][x2_vari+1] != 0) do not reevaluate if no changes were made */
            {
              if (tot_eq != 0)
                {
                  for(j=1; j<=x2_vari + tot_eq; j++)
                    X[j] = 0.0;

                  find_X(fin_mat,population[i],X,x2_vari,tot_eq,x1,x2,a1_b);
                }
              else
                for(j=1; j<=x2_vari; j++)
                   X[j] = population[i][j];

              population[i][0] = evaluate(X);       
            } 
        }


  /* Evaluate the best in population and assign it to Teval */
      sort(MinMax,population,pop_size);
        
/*****************************************************************/
/*Initialize the initvector which will be used during epochs if population*/
/*is stuck at one point. prevvector is used to compare the performance of */
/*an epoch and the bestvector is the best so far vector.*/
  	  for(i=0; i<=x2_vari; i++)
          {
        	init_vec[i]=population[1][i];
        	prev_vec[i]=population[1][i];
        	best_vec[i]=population[1][i];
      	  }
        	init_vec[x2_vari+1] = 0;
        	prev_vec[x2_vari+1] = 0;
        	best_vec[x2_vari+1] = 0;
		prev_change_at = init_vec[0];

  fprintf(output,"\n\n");
  fprintf(output,"\n\nGeneration#\t    Solution Value\n");

  probab     = vector(1,pop_size);
  /*Assigning probability of survival for each of the agent, with the*/
  /*probability provided by the user for the best agent*/
  assign_probab(probab,pop_size,Q);

  /*Finding the cumulative probability of the agents*/
  find_cum_probab(cum_probab,probab,pop_size);
      free_vector(probab     ,1);



  Teval = population[1][0]; peak_val=population[1][0];
  for(j=1; j<=pop_size; j++)
    new_genera[j][x2_vari+1] = 0.0;

  /*Reproducing and evaluating for the total number of generations times*/
  do
    {	do {
      /*Initializing the live and die vectors*/
      for(j=1; j<=pop_size; j++)
        {
          live[j] = die[j] = 0;
          for(i=0; i<=x2_vari + 1; i++)
            new_genera[j][i] = population[j][i];
        }

      /*Finding the agents that will die and the agents that will reproduce*/
      find_live(cum_probab,live,pop_size,P4+P5+P7);
      j1=j2=j3=j4=j5=j6=j7=0;

      while(j1+j2+j3+j4+j4+j5+j5+j6+j7+j7 < P)
        { 
          oper = irange_ran(1,7);
          switch (oper)
            {
              case 1:
                     /*Applying the first operator, uniform mutation, for the number of times specified*/
                    if (j1 != P1)
                    {
                       do        /*reselect parent if condit1 is not satified*/ 
                       {
                         do
                           first = irange_ran(2,pop_size);
                         while (die[first] == 1);
                         die[first] = 1;

                         new_genera[first][x2_vari+1] = 1.0;
                         for(i=1; i<=x2_vari; i++)
                            t_vec[i] = population[first][i];
                         condit1 = oper1(t_vec,fin_mat,rc,intarr);

                         if (condit1)
                          { for(i=1; i<=x2_vari; i++)
                              new_genera[first][i] = t_vec[i];
			  }

                         j1++;
                        } while ((!condit1) && (j1 <= P1));
                     }
                    break;
              case 2:
                     /*Applying the second operator, boundary mutation, for the number of times specified*/
                    if (j2 != P2)
                    {
                       do        /*reselect parent if condit2 is not satified*/
                       {
                          do
                            first = irange_ran(2,pop_size);
                          while (die[first] == 1);
                          die[first] = 1;

                          new_genera[first][x2_vari+1] = 2.0;
                          for(i=1; i<=x2_vari; i++)
                             t_vec[i] = population[first][i];
                          condit2 = oper2(t_vec,fin_mat,rc,intarr);

                          if (condit2)
                             for(i=1; i<=x2_vari; i++)
                                new_genera[first][i] = t_vec[i];
                          j2++;
                        } while ((!condit2) && (j2 <= P2));
                     }
                    break;
              case 3:
                  /*Applying the third operator, non-uniform mutation, for the number of times specified*/
                    if (j3 != P3)
                    {
                       do        /*reselect parent if condit3 is not satified*/
                       {
                          do
                            first = irange_ran(2,pop_size);
                          while (die[first] == 1);
                          die[first] = 1;

                          new_genera[first][x2_vari+1] = 3.0;
                          for(i=1; i<=x2_vari; i++)
                             t_vec[i] = population[first][i];
                          condit3 = oper3(t_vec,fin_mat,rc,generations,count_gener,B,intarr); 

                          if (condit3)
                             for(i=1; i<=x2_vari; i++)
                                new_genera[first][i] = t_vec[i];
                          j3++;
                        } while ((!condit3) && (j3 <= P3));
                     }
                    break;
              case 4:
                   /*Applying the fourth operator, whole arithmetical crossover*/
                    if (j4 != (int) P4/2)
                      {
                        /*Find two distinct parents for crossover operator 4*/
                        first_live  = find_parent(live,pop_size);
                        second_live = find_parent(live,pop_size);
                        same = TRUE;
                        for(i=1; i<=x2_vari; i++)
                          if (population[first_live][i] != population[second_live][i])
                            same = FALSE;
                        if (!same)
                          {
                            first_die   = find_die(cum_probab, die ,pop_size);
                            second_die  = find_die(cum_probab, die ,pop_size);
                            die[first_die]  = 1;
                            die[second_die] = 1;
                            new_genera[first_die][x2_vari+1]  = 4.0;
                            new_genera[second_die][x2_vari+1] = 4.0;
                            for(i=1; i<=x2_vari; i++)
                              {
                                temp[1][i] = population[first_live][i];
                                temp[2][i] = population[second_live][i];
                              }
                            oper4(temp[1],temp[2],x2_vari,intarr,rc,fin_mat); 
		if(satis_con(temp[1],fin_mat,rc))
                        for(i=1; i<=x2_vari; i++)
                              {
                                new_genera[first_die][i]  = temp[1][i];
                              }
		if(satis_con(temp[2],fin_mat,rc))
                        for(i=1; i<=x2_vari; i++)
                              {
                                new_genera[second_die][i] = temp[2][i];
                              }
                          }
                        j4++;
                      }
                    break;
              case 5:
                    /*Applying the fifth operator, simple arithmetical crossover*/
                    if (j5 != (int) P5/2)
                      {
                        /*Find two distinct parents for crossover operator 5*/
                        first_live  = find_parent(live,pop_size);
                        second_live = find_parent(live,pop_size);
                        same = TRUE;
                        for(i=1; i<=x2_vari; i++)
                          if (population[first_live][i] != population[second_live][i])
                            same = FALSE;
                        if (!same)
                          {
                            first_die   = find_die(cum_probab, die ,pop_size);
                            second_die  = find_die(cum_probab, die ,pop_size);
                            die[first_die]  = 1;
                            die[second_die] = 1;
                            new_genera[first_die][x2_vari+1]  = 5.0;
                            new_genera[second_die][x2_vari+1] = 5.0;
                            for(i=1; i<=x2_vari; i++)
                              {
                                temp[1][i] = population[first_live][i];
                                temp[2][i] = population[second_live][i];
                              }
                            oper5(temp[1],temp[2],STEP,rc,fin_mat,intarr); 
		if(satis_con(temp[1],fin_mat,rc))
                        for(i=1; i<=x2_vari; i++)
                              {
                                new_genera[first_die][i]  = temp[1][i];
                              }
		if(satis_con(temp[2],fin_mat,rc))
                        for(i=1; i<=x2_vari; i++)
                              {
                                new_genera[second_die][i] = temp[2][i];
                              }
                          }
                        j5++;
                      }
                    break;
              case 6:
                    /*Applying the sixth operator, whole non-uniform mutation, for the number of times specified*/
                    if (j6 != P6)
                    {
                       do        /*reselect parent if condit6 is not satified*/
                       {
                          do
                            first = irange_ran(2,pop_size);
                          while (die[first] == 1);
                          die[first] = 1;

                          new_genera[first][x2_vari+1] = 6.0;
                          for(i=1; i<=x2_vari; i++)
                             t_vec[i] = population[first][i];
                          condit6 = oper6(t_vec,fin_mat,rc,generations,count_gener,B,intarr); 
  
                          if (condit6)
                             for(i=1; i<=x2_vari; i++)
                                new_genera[first][i] = t_vec[i];
                          j6++;
                        } while ((!condit6) && (j6 <= P6));
                     }
                    break;
              case 7:
                    /*Applying the seventh operator*/
                    if (j7 != (int) P7/2)
                      {
                        /*Find two distinct parents for operator 7*/
                        first_live  = find_parent(live,pop_size);
                        second_live = find_parent(live,pop_size);
                        same = TRUE;
                        for(i=1; i<=x2_vari; i++)
                          if (population[first_live][i] != population[second_live][i])
                            same = FALSE;
                        if (!same)
                          {
                            first_die   = find_die(cum_probab, die ,pop_size);
                            die[first_die]  = 1;
                            new_genera[first_die][x2_vari+1]  = 7.0;
                            for(i=1; i<=x2_vari; i++)
                              if (first_live < second_live)  /* first agent is better agent */
                                {
                                  temp[2][i] = population[first_live][i];
                                  temp[1][i] = population[second_live][i];
                                }
                              else                          /* second agent is better agent */
                                {
                                  temp[2][i] = population[second_live][i];
                                  temp[1][i] = population[first_live][i];
                                }
                            oper7(temp[1],temp[2],rc,fin_mat,intarr);
  		if(satis_con(temp[1],fin_mat,rc))
                            for(i=1; i<=x2_vari; i++)
                              new_genera[first_die][i]  = temp[1][i];
                          }
                        j7++;
                      }
                      break;
               default : printf("default\n");
            }
        }

      /*Replace the population with the new generation */
      nepw = new_genera;
      new_genera = population;
      population = nepw;

      /*Evaluate each of the agents in the new population*/
      for(i=1; i<=pop_size; i++)
        {
          /*if (population[i][x2_vari+1] != 0) */      /* do not reevaluate if no changes were made */
            {
              if (tot_eq != 0)
                {
                  for(j=1; j<=x2_vari + tot_eq; j++)
                    X[j] = 0.0;

                  find_X(fin_mat,population[i],X,x2_vari,tot_eq,x1,x2,a1_b);
                }
              else
                for(j=1; j<=x2_vari; j++)
                   X[j] = population[i][j];

              population[i][0] = evaluate(X);  
	/*Total checking for error free output. 
		if(i!=0) 		
		if(!satis_con(population[i],fin_mat,rc))
				{
					for(k=0;k<=x2_vari;k++)
					population[i][k]=population[i-1][k];
				}
	End of total checking. */
           } 

        }

      /*Sort the new population based on their evaluation function*/
      sort(MinMax,population,pop_size);
/*if(satis_con(population[1],fin_mat,rc))*/
      { switch(MinMax)
        {
          case 0:
            if(Teval > population[1][0])
              {
                Teval = population[1][0];
 fprintf(output,"Generation: %7lu \t%18.8f\n",count_gener,population[1][0]);                peak_cnt = count_gener;
                peak_val = population[1][0];
              }
            break;
          case 1:
            if(Teval < population[1][0])
              {
                Teval = population[1][0];
                fprintf(output,"Generation: %7lu \t%18.8f\n",count_gener,population[1][0]);
                peak_cnt = count_gener;                
                peak_val = population[1][0];
          }
            break;
        }
       }
/*	#if DOS_SYS
      		gotoxy(5,7);
	#endif
*/	/*Check and replace all elements by the best for an epoch.*/
    condit = condit1 && condit2 && condit3 && condit6; 
	if(TYPE==1)
		counter++;
	if(TYPE==0)
		{	l=1;
			best_gen[count_gener]=population[1][0];
			if(counter>numofgen)
			{	
		kk=best_gen[count_gener]-best_gen[count_gener-numofgen];
		if( ( kk < 0 ? -1 * kk : kk )< delta)
				{	
					l=0;
				}
				else l=1;
			}
			counter++;
		}
	if(TYPE==2)l=1;
        count_gener++;
	
   }while(((TYPE==1)?counter<epoch:l)&&(count_gener<generations));


/*Start of code for variable epoch. The best gene is copied into the*/
/* whole population.*/

if((TYPE==0)&&(count_gener<generations))
{	counter=0;
	/*If it's a maximization problem*/
	if(MinMax==1)
	{
  /*If present best is better than bestsofar, copy it into population.*/
		if(population[1][0]>best_vec[0])
		{	
			for(k=0;k<=x2_vari;k++)
			best_vec[k] = population[1][k];

			for(i=1;i<pop_size;i++)	
			for(k=0;k<=x2_vari;k++)
				population[i][k]=best_vec[k];
		}	
 /*Else copy initvector as it has less chance of being a local optima.*/
		else
		{	
			for(i=1;i<pop_size;i++)	
			for(k=0;k<=x2_vari;k++)
				population[i][k]=init_vec[k];
		}
	}
	/*If it's a minimization problem*/
	if(MinMax==0)
	{
  /*If present best is better than bestsofar, copy it into population.*/
		if(population[1][0]<best_vec[0])
		{	
			for(k=0;k<=x2_vari;k++)
			best_vec[k] = population[1][k];

			for(i=1;i<pop_size;i++)	
			for(k=0;k<=x2_vari;k++)
				population[i][k]=best_vec[k];
		}	
 /*Else copy initvector as it has less chance of being a local optima.*/
		else
		{
			for(i=1;i<pop_size;i++)	
			for(k=0;k<=x2_vari;k++)
				population[i][k]=init_vec[k];

		}
	}
}


/*Start of the code for fixed epoch size. */
if((TYPE==1)&&(count_gener<generations)) {	
	counter=0;
/*IF there is change in this epoch, load the best of previous generation.*/
	if(prev_vec[0]!=population[1][0]) 
	{
		if(satis_con(population[1],fin_mat,rc))
			for(i=0;i<pop_size;i++)	
			for(k=0;k<=x2_vari;k++)
				population[i][k]=population[1][k];
		else
			for(i=1;i<pop_size;i++)	
			for(k=0;k<=x2_vari;k++)
				population[i][k]=prev_vec[k];
	}
/*If there is no change during each epoch, then load the initial point.*/
	else
	{
		kk=population[1][0];
	/*If it's a maximization problem*/
		if(MinMax==1)
		{	
			if(population[1][0]>best_vec[0])
				for(i=1;i<pop_size;i++)	
				for(k=0;k<=x2_vari;k++)
					population[i][k]=population[1][k];
			else
			{	
				if(prev_change_at>population[1][0])
				for(i=1;i<pop_size;i++)	
				for(k=0;k<=x2_vari;k++)
					population[i][k]=best_vec[k];
				else
				for(i=1;i<pop_size;i++)	
				for(k=0;k<=x2_vari;k++)
					population[i][k]=init_vec[k];

			}
		}
	/*If it's a minimization problem*/
		if(MinMax==0)
		{
			if(population[1][0]<best_vec[0])
				for(i=1;i<pop_size;i++)	
				for(k=0;k<=x2_vari;k++)
					population[i][k]=population[1][k];
			else
			{	if(prev_change_at<population[1][0])
				for(i=1;i<pop_size;i++)	
				for(k=0;k<=x2_vari;k++)
					population[i][k]=best_vec[k];
				else
				for(i=1;i<pop_size;i++)	
				for(k=0;k<=x2_vari;k++)
					population[i][k]=init_vec[k];

			}
		}
			
		prev_change_at=kk;
	}
/*Store the present best for comparison with best of next epoch.*/
		for(k=0;k<=x2_vari;k++)
		prev_vec[k]=population[1][k];
/*Save the best so far value.*/		
		if(MinMax==1)
		{	if(best_vec[0]<prev_vec[0])
			for(k=0;k<=x2_vari;k++)
			best_vec[k] = prev_vec[k];
		}
		else if(MinMax==0)
		{	if(best_vec[0]>prev_vec[0])
			for(k=0;k<=x2_vari;k++)
			best_vec[k] = prev_vec[k];
		}
	}

    }
  while (count_gener <= generations);


  fprintf(output, "\nBest solution was found at generation %lu (solution value = %.8f)\n", peak_cnt,peak_val);
  fprintf(output,"\n\nBest solution found:\n\n");
if(TYPE!=2)
  find_X(fin_mat,best_vec,X,x2_vari,tot_eq,x1,x2,a1_b);
else
  find_X(fin_mat,population[1],X,x2_vari,tot_eq,x1,x2,a1_b);

  for(j = 1; j <= x2_vari+tot_eq; j++)
   fprintf(output," X[%2d] :\t%18.8f\n",j,X[j]);
    free_matrix(population ,1,pop_size,0);
     free_matrix(new_genera ,1,pop_size,0);
    free_matrix(temp       ,1,2,1);
    free_vector(t_vec      ,1);
    free_vector(cum_probab ,1);
    free_ivector(live      ,1);
    free_ivector(die       ,1);

}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   sort()                                       */
/*                                                                              */
/*           SYNOPSIS          :   void sort(MinMax, population,pop_size)       */
/*                                                                              */
/*           DESCRIPTION       :   This function sorts the population, in the   */
/*                                  ascending or the descending order of the    */
/*                                  evaluation function, depending on whether   */
/*                                  it is a maximization or a minimization      */
/*                                  function, respectively.                     */
/*                                                                              */
/*                                  As an alternative, the sortq function below */
/*                                  can be used, That sorting function uses     */
/*                                  the quicksort algorithm.                    */
/*                                                                              */
/*                                                                              */
/*           FUNCTIONS CALLED  :   swap()                                       */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*          A               9/11/92       Tom Logan      Rewrote                */
/*                                                                              */
/********************************************************************************/
void sort(int MinMax,MATRIX population,int pop_size)
       /*Tells whether it is a maximizaiton or a minimization function*/
       /*Population size*/
       /*Array of population*/
{
  int i,j,k;


  /*If MinMax is 0 sorts in the descending order, and*/
  /*if it is 1 sorts in the ascending order*/
  /*Sorted in ascending or descending order, based on*/
  /*the evaluated values of each of the agents*/
  switch(MinMax)
    {
    case 0 :
      for(i=1; i<=pop_size; i++)
        for(j=i+1; j<=pop_size; j++)
          if(population[i][0] > population[j][0])
            swap(&population[i],&population[j]);
      break;

    case 1 :
      for(i=1; i<=pop_size; i++)
        for(j=i+1; j<=pop_size; j++)
          if(population[i][0] < population[j][0])
            swap(&population[i],&population[j]);
      break;
    default:
      fprintf(output,"Incorrect data: Must be a 0 or 1");
      exit(1);
    }
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   swap()                                       */
/*                                                                              */
/*           SYNOPSIS          :   void swap(x,y)                               */
/*                                                                              */
/*           DESCRIPTION       :   This function interchanges the values of     */
/*                                  x and y.                                    */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   sort()                                       */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void swap(float **x,float**y)
{
  float *temp;

  temp = *x;
  *x = *y;
  *y = temp;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_parent()                                */
/*                                                                              */
/*           SYNOPSIS          :   int find_parent(live,pop_size)               */
/*                                                                              */
/*           DESCRIPTION       :   This function returns the index of the       */
/*                                  agent in the population, which is to be     */
/*                                  chosen for reproduction.                    */
/*                                                                              */
/*           FUNCTIONS CALLED  :   irange_ran()                                 */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/
int find_parent(IVECTOR live,int pop_size)
 /*Population size*/
 /*Vector containing the number of times each agent*/
              /*is going to reproduce*/
{
  int i,temp,t1,tot=0;

  /*Finding the total number of parents to reproduce*/
  for(i=1; i<=pop_size; i++)
    tot = tot + live[i];
  if(tot==0)
    {
      printf("No agents to select\n");
      exit(1);
    }

  /*Choosing one of them randomly*/
  temp = irange_ran(1,tot);

  tot = 0;
  i = 1;
  do{
    if(live[i]!=0)
      t1 = i;
    tot = tot + live[i++];
  }while(tot<temp);

  /*Decrementing the number of times the parent chosen is going to reproduce*/
  live[t1]--;
  return(t1);
}
/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   assign_probab()                              */
/*                                                                              */
/*           SYNOPSIS          :   void assign_probab(probab,pop_size,Q)        */
/*                                                                              */
/*           DESCRIPTION       :   This function assigns probability of survival*/
/*                                  to each of the agents determined by the     */
/*                                  value provided by the user for the          */
/*                                  probability of the best agnet.              */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void assign_probab(VECTOR probab,int pop_size,double Q)
 /*Population size*/
      /*The probability of survival of the best agent*/
 /*Array to contain the probability of survival*/
               /* of each of the agents*/
{
  int i;
  double Q1;

  /* Q, Q(1-Q)^1, Q(1-Q)^2 ... Q(1-Q)^n */
  Q1 = Q/(1 - x_pow_y(1-Q,pop_size));
  for(i=1; i<=pop_size; i++)
    probab[i] = Q1 * x_pow_y(1-Q,i-1);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   assign_probab()                              */
/*                                                                              */
/*           SYNOPSIS          :   void assign_probab(probab,pop_size,Q)        */
/*                                                                              */
/*           DESCRIPTION       :   This function assigns probability of survival*/
/*                                  to each of the agents determined by the     */
/*                                  value provided by the user for the          */
/*                                  probability of the best agnet.              */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/



float x_pow_y(float x,int y)
{
  int i;
  float tot = 1.0;

  for(i=0; i < y; i++)
    tot = tot * x;
  return(tot);
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_cum__probab()                           */
/*                                                                              */
/*           SYNOPSIS          :   void find_cum__probab(cum_probab,probab,     */
/*                                                                     pop_size)*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the cumulative           */
/*                                  probability of each of the agents, from the */
/*                                  individual probability found earlier.       */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void find_cum_probab(VECTOR cum_probab,VECTOR probab,int pop_size)
   /*Population size*/
    /*Individual probability of survival of each of the agent*/
     /*Cumulative probability of survival of each of the agent*/
{
  int i;

  cum_probab[1] = probab[1];

  for(i=2; i<=pop_size; i++)
    cum_probab[i] = cum_probab[i-1] + probab[i];

}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_live()                                  */
/*                                                                              */
/*           SYNOPSIS          :   void find_live(cum_probab,live,pop_size,P4+P5*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the agents from the      */
/*                                  population, who are going to live - those   */
/*                                  who are going to reproduce, which is done   */
/*                                  based on the cumulative probability of      */
/*                                  survival of each of the agents.             */
/*                                                                              */
/*           FUNCTIONS CALLED  :   frange_ran()                                 */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Tom Logan                                    */
/*                                                                              */
/*           DATE              :   9/15/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void find_live(VECTOR cum_probab,IVECTOR live,int pop_size,int P)
 /*Cumulative probability*/
      /*Agents that are going to reproduce*/
      /*Population size*/
             /*Total number of parents needed to reproduce*/
{
  float random;
  int count=0,/*Count of the number of agents chosen to live*/
      i;

  do
    {
      /*Choosing a random cumulative probability*/
      random = frange_ran(0.0,1.0);
      i=0;
      /*Finding the agent with the chosen cumulative probability*/
      do{
        i++;
        }while((random > cum_probab[i]) && (i< pop_size));

      /*Chosing the parent with that probability to reproduce*/
      if(count < P)
        {
          live[i]++;
          count++;
        }
    }while(count < P);
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_die()                                   */
/*                                                                              */
/*           SYNOPSIS          :   void find_die(cum_probab,die,pop_size,P4+P5) */
/*                                                                              */
/*           DESCRIPTION       :   This function finds the agents from the      */
/*                                  population, who are going to die.            /
/*                                                                              */
/*           FUNCTIONS CALLED  :   frange_ran()                                 */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Tom Logan                                    */
/*                                                                              */
/*           DATE              :   9/15/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/


int find_die(VECTOR cum_probab,IVECTOR die,int pop_size)
 /*Cumulative probability*/
    /*Agents that are going to die*/
 /*Population size*/
{
  float random;
  int i;
  int done = FALSE;

  do
    {
      /*Choosing a random cumulative probability*/
      random = frange_ran(0.0,1.0);
      i=0;
      /*Finding the agent with the chosen cumulative probability*/
      do{
        i++;
        }
      while((random > cum_probab[i]) && (i< pop_size));

      /*Chosing the agent to die*/
      if ((die[pop_size+1-i] == 0) && (i < pop_size))
        done = TRUE;
    }
  while(!done);
  return(pop_size+1-i);
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_X()                                     */
/*                                                                              */
/*           SYNOPSIS          :   void find_X(final,agen.X,x2_vari,tot_eq,x1,  */
/*                                                                           x2)*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the value of all the     */
/*                                  variables in the original problem, with     */
/*                                  the values of the remaining variables.      */
/*                                                                              */
/*           FUNCTIONS CALLED  :   none                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/


void find_X(MATRIX final,VECTOR agent,VECTOR X,int x2_vari,int tot_eq,IVECTOR x1,IVECTOR x2,VECTOR a1_b)
{
  int i,j;

  for(j=1; j<=x2_vari; j++)
    X[x2[j]] = agent[j];

  for(j = 1; j<=tot_eq; j++)
    {
      X[x1[j]] = a1_b[j];
      for(i=1; i<=x2_vari; i++)
        X[x1[j]] = X[x1[j]] + agent[i] * final[j+x2_vari][i+1];
    }
}


