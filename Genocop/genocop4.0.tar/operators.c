#include "genocop.h"
#if DOS_SYS
  extern unsigned long count_gener;
#endif

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   oper1()                                      */
/*                                                                              */
/*           SYNOPSIS          :   FLAG oper1(parent,fin_mat,rc)                */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a Flag and generates a */
/*                                 new vector from parent vector, after applying*/
/*                                 the operator1, uniform mutation.             */ 
/*           FUNCTIONS CALLED  :   find_range(),                                */
/*                                 frange_ran(),                                */
/*                                 irange_ran(),                                */
/*                                 vector().                                    */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                  
*/
/*                                                                              */
/********************************************************************************/
FLAG oper1(VECTOR parent,MATRIX fin_mat,INDEX rc,IVECTOR arri)
/*The parent vector*/
/*The final matrix*/
/*Row and column of the final matrix*/
{
	int comp, counter = 1;
	float llim,ulim;
	int tllim,tulim;
	int p; 
	float q;
  	FLAG condit = TRUE;
  do{   /*if condit is not satified, reselect a variable*/
	comp = irange_ran(1,rc.c-2);
	find_range(&llim,&ulim,comp,fin_mat,rc,parent);
	if(arri[comp]==2)
	{	/*Find the feasible upper and lower limits for integer vars. */
		if(ulim>=0)	tulim=ulim;
		if(ulim<0)
		{	
			p=ulim;
			q=ulim-p;
			if(q!=0)p=ulim-1;
			else p=ulim;
			tulim=p;
		}
		if(llim>0)
		{	
			p=llim;
			q=llim-p;
			if(q!=0)p=llim+1;
			else p=llim;
			tllim=p;
		}
		if(llim<=0)	tllim=llim;
		parent[comp] = irange_ran(tllim,tulim);
	}
	else if(arri[comp]==3)
		parent[comp] = (flip() == TAIL) ? 0 : 1;
	     else
		parent[comp] = frange_ran(llim,ulim);
      counter++;    /*count the number of variables been selected*/
  } while (!(condit = satis_con(parent, fin_mat, rc)) && (counter <= rc.c-2));
  return (condit);
}



/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   oper2()                                      */
/*                                                                              */
/*           SYNOPSIS          :   FLAG oper2(parent,fin_mat,rc)                */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a Flag and generates a */
/*                                 new vector from parent vector, after applying*/
/*                                 the operator2, boundary mutation.            */
/*                                                                              */
/*           FUNCTIONS CALLED  :   find_range(),                                */
/*                                 flip(),                                      */
/*                                 irange_ran(),                                */
/*                                 vector().                                    */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*            A            9/9/96         Li Cui         boundary checking      */
/*                                                                              */
/********************************************************************************/


FLAG oper2(VECTOR parent,MATRIX fin_mat,INDEX rc,IVECTOR arri)
{
	int comp,counter = 1;
	float llim,ulim;
	float temp_ll,temp_ul;
  	FLAG condit = TRUE;
	int p; 
	float q;
  do            /*if condit is not satified, reselect a variable*/
  {
	comp = irange_ran(1,rc.c-2);

	find_range(&llim,&ulim,comp,fin_mat,rc,parent);

	 temp_ll=llim;
	 temp_ul=ulim;
	if(arri[comp]==2)
	{	/*Find the feasible upper and lower limits for integer vars. */
		if(ulim>=0)	temp_ul=(int)ulim;
		if(ulim<0)
		{	
			p=ulim;
			q=ulim-p;
			if(q!=0)p=ulim-1;
			else p=ulim;
			temp_ul=p;
		}
		if(llim>0)
		{	
			p=llim;
			q=llim-p;
			if(q!=0)p=llim+1;
			else p=llim;
			temp_ll=p;
		}
		if(llim<=0)	temp_ll=(int)llim;
	}
	if(arri[comp]==3)
	{
		temp_ll= 0 ;
		temp_ul=1;
	}

	parent[comp] = (flip() == TAIL) ? temp_ll : temp_ul;
    counter++;      /*count the number of variables been selected*/
  } while ( !(condit = satis_con(parent, fin_mat, rc)) && (counter <= rc.c-2)); 
 return (condit);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   oper3()                                      */
/*                                                                              */
/*           SYNOPSIS          :   FLAG oper3(parent,fin_mat,r,c,T,t,B)         */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a Flag and generates a */
/*                                 new vector from parent vector, after applying*/
/*                                 the operator3, non-uniform mutation.         */ 
/*           FUNCTIONS CALLED  :   find_range(),                                */
/*                                 flip(),                                      */
/*                                 get_F(),                                     */
/*                                 irange_ran(),                                */
/*                                 vector().                                    */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*            A             9/9/96        Li Cui         boundary checking      */
/*                                                                              */
/********************************************************************************/


FLAG oper3(VECTOR parent,MATRIX fin_mat,INDEX rc,unsigned long T,unsigned long t,int B,IVECTOR arri)
/*Total number of generations*/
/*Current generation number*/
{
	int comp, counter = 1;
	float llim,ulim;
  	FLAG condit = TRUE;
  	float check;
	int p; 
	float q;
	int tllim,tulim;
  do               /*if condit is not satified, reselect a variable*/
  {
	tllim=0;
	tulim=0;
	comp = irange_ran(1,rc.c-2);
	find_range(&llim,&ulim,comp,fin_mat,rc,parent);
	if(arri[comp]==2)
	{	/*Find the feasible upper and lower limits for integer vars. */
		if((parent[comp]<llim)||(parent[comp]>ulim))
		{ 	
			if(ulim>=0)	tulim=ulim;
			if(ulim<0)
			{	
				p=ulim;
				q=ulim-p;
				if(q!=0)p=ulim-1;
				else p=ulim;
				tulim=p;
			}
			if(llim>0)
			{	
				p=llim;
				q=llim-p;
				if(q!=0)p=llim+1;
				else p=llim;
				tllim=p;
			}
			if(llim<=0)	tllim=llim;
			parent[comp] = irange_ran(tllim,tulim);
		}
		check=parent[comp];
		parent[comp] = (flip() == TAIL) ? 
		    parent[comp]-get_F(T,t,parent[comp]-llim,B,2)
		    :parent[comp]+get_F(T,t,ulim-parent[comp],B,2);
		parent[comp]=(int)parent[comp];
	}
	else if(arri[comp]==1)
	{
		if((parent[comp]<llim)||(parent[comp]>ulim))
			parent[comp] = frange_ran(llim,ulim);

		parent[comp] = (flip() == TAIL) ? 		
		    parent[comp]-get_F(T,t,parent[comp]-llim,B,1)
		    :parent[comp]+get_F(T,t,ulim-parent[comp],B,1);
	}
	else 
	parent[comp]=(flip()==TAIL) ? 0:1;
    counter++;  /*counte the number of variables been selected*/
  } while (!(condit = satis_con(parent, fin_mat, rc)) && (counter <= rc.c-2));
  return (condit);
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   oper4()                                      */
/*                                                                              */
/*           SYNOPSIS          :   MATRIX oper4(p1,p2,x2_vari)                  */
/*                                                                              */
/*           DESCRIPTION       :   This function returns two new vectors        */
/*                                  generated after whole arithmetical          */
/*                                  crossover, from the two parent vectors.     */
/*                                                                              */
/*           FUNCTIONS CALLED  :   matrix()                                     */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*            A             10/1/92         Tom Logan    Parameter A is now     */
/*                                                       random(0-1)            */
/*                                                                              */
/********************************************************************************/

void oper4(VECTOR p1,VECTOR p2,int x2_vari,IVECTOR arri,INDEX rc,MATRIX fin_mat)
/*The two parents chosen for crossover*/
/*Length of the vector*/
{
	MATRIX child;
	int i;
	float  A;
	FLAG _CHECK1= FALSE,_CHECK2= FALSE;
	int p; 
	float q;
	int tllim,tulim;
	float llim1,ulim1,llim2,ulim2;
	child = matrix(1,2,1,x2_vari);
	do
		A = frange_ran(0.0,1.0);
	while (A==0);

	for(i=1; i<=x2_vari; i++)
	{
		if(arri[i]==2)
		{
			find_range(&llim1,&ulim1,i,fin_mat,rc,p1);
			find_range(&llim2,&ulim2,i,fin_mat,rc,p2);
			if((p1[i]<llim1)||(p1[i]>ulim1))
			{	
/*Find the feasible upper and lower limits for integer vars. */
				if(ulim1>=0)	tulim=ulim1;
				if(ulim1<0)
				{	
					p=ulim1;
					q=ulim1-p;
					if(q!=0)p=ulim1-1;
					else p=ulim1;
					tulim=p;
				}
				if(llim1>0)
				{	
					p=llim1;
					q=llim1-p;
					if(q!=0)p=llim1+1;
					else p=llim1;
					tllim=p;
				}
				if(llim1<=0)	tllim=llim1;
				p1[i] = irange_ran(tllim,tulim);
			}
			if((p2[i]<llim2)||(p2[i]>ulim2))
			{	
/*Find the feasible upper and lower limits for integer vars. */
				if(ulim2>=0)	tulim=ulim2;
				if(ulim2<0)
				{	
					p=ulim2;
					q=ulim2-p;
					if(q!=0)p=ulim2-1;
					else p=ulim2;
					tulim=p;
				}
				if(llim2>0)
				{	
					p=llim2;
					q=llim2-p;
					if(q!=0)p=llim2+1;
					else p=llim2;
					tllim=p;
				}
				if(llim2<=0)	tllim=llim2;
				p2[i] = irange_ran(tllim,tulim);
			}
			if(p1[i]!=p2[i])
			{
			child[1][i] =(int)( p1[i] * A + p2[i] * (1.0-A) );
			child[2][i] =(int)( p2[i] * A + p1[i] * (1.0-A) );
			}
			else
			{	child[1][i] =p1[i];
				child[2][i]=p2[i];
			}
		}
		else if(arri[i]!=2)
		{
			child[1][i] = p1[i] * A + p2[i] * (1.0-A);
			child[2][i] = p2[i] * A + p1[i] * (1.0-A);
			if(arri[i]==3)
			{	if(child[1][i]>0.5)
					child[1][i]=1;
				else  child[1][i]=0;
				if(child[2][i]>0.5)
					child[2][i]=1;
				else child[2][i]=0;
			}
		} 
			
	}

	_CHECK1 = satis_con(child[1],fin_mat,rc);
	_CHECK2 = satis_con(child[2],fin_mat,rc);

	if(_CHECK1)
	for(i=1; i<=x2_vari; i++)
	{
    		p1[i] =child[1][i];
	}
		
	if(_CHECK2)
	for(i=1; i<=x2_vari; i++)
	{
		p2[i] =child[2][i];
	}
	free_matrix(child,1,2,1);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   oper5()                                      */
/*                                                                              */
/*           SYNOPSIS          :   MATRIX oper5(p1,p2,STEP,rc,fin_mat,X,x2)     */
/*                                                                              */
/*           DESCRIPTION       :   This function returns two new vectors        */
/*                                  generated after simple arithmetical         */
/*                                  crossover, from the two parent vectors.     */
/*                                                                              */
/*           FUNCTIONS CALLED  :   irange_ran()                                 */
/*                                 matrix(),                                    */
/*                                 satis_con()                                  */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void oper5(VECTOR p1,VECTOR p2,int STEP,INDEX rc,MATRIX fin_mat,IVECTOR arri)
/*The two parents for crossing over*/
/*Row and column of the final matrix*/
/*The final matrix*/
/*Parameter for the crossover*/
{
	MATRIX child;
	FLAG _CHECK1 = FALSE,_CHECK2 = FALSE;
	int i,n=1,cut,p;
	child = matrix(1,2,1,rc.c-2);

	cut = irange_ran(1,rc.c-2);
	for(i=1; i<=cut; i++)
	{
		child[1][i] = p1[i];
		child[2][i] = p2[i];
	}
	do
	{
		for(i=cut + 1; i<=rc.c-2; i++)
		{
			if(p1[i]!=p2[i])
			{
child[1][i] = p1[i] * (float)n/(float)STEP + p2[i] * (1.0-(float)n/(float)STEP);
child[2][i] = p2[i] * (float)n/(float)STEP + p1[i] * (1.0-(float)n/(float)STEP);
			}
			else
			{
				child[1][i]=p1[i];
				child[2][i]=p1[i];	
			}
			
			if(arri[i]==2)
			{
				child[1][i] = (int)child[1][i];
				child[2][i] = (int)child[2][i];
			}
			if(arri[i]==3)
			{	if(child[1][i]>0.5)
					child[1][i]=1;
				else  child[1][i]=0;
				if(child[2][i]>0.5)
					child[2][i]=1;
				else child[2][i]=0;
			}
		}
		_CHECK1 = satis_con(child[1],fin_mat,rc);
		_CHECK2 = satis_con(child[2],fin_mat,rc);
		n++;
	}while((n<=STEP) && ((_CHECK1 == FALSE) || (_CHECK2 == FALSE)));
	if(_CHECK1)
	for(i=1;i<=rc.c-2;i++)
		p1[i]=child[1][i];
	if(_CHECK2)
	for(i=1;i<=rc.c-2;i++)
		p2[i]=child[2][i];
	free_matrix(child,1,2,1);
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   oper6()                                      */
/*                                                                              */
/*           SYNOPSIS          :   FLAG oper6(parent,fin_mat,r,c,T,t,B)         */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a Flag and generates a */
/*                                 new vector from parent vector, after applying*/
/*                                 the operator6, whole non-uniform mutation.   */ 
/*           FUNCTIONS CALLED  :   find_range(),                                */
/*                                 flip(),                                      */
/*                                 get_F(),                                     */
/*                                 irange_ran(),                                */
/*                                 vector().                                    */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*            A             9/1/92       Tom Logan                              */
/*            B             9/9/96        Li Cui         boundary checking      */
/********************************************************************************/

FLAG oper6(VECTOR parent,MATRIX fin_mat,INDEX rc,unsigned long T,unsigned long t,int B,
IVECTOR arri)
{
	int  comp,i,num,*next;
	float llim,ulim;
  	FLAG condit = TRUE;
	int p; 
	float q,check;
	float temp;
	int tllim,tulim;

	next = ivector(1, rc.c-2);
	for(i=1; i<=rc.c-2; i++)
		next[i] = 0;

	for (i=1; i<=rc.c-2; i++)
	{
		do
			comp = irange_ran(1, rc.c-2);
		while (next[comp] == 1);
		next[comp] = 1;
		find_range(&llim,&ulim,comp,fin_mat,rc,parent);
		if(arri[comp]==2)
		{
/*Find the feasible upper and lower limits for integer vars. */			if((parent[comp]<llim)||(parent[comp]>ulim))
			{ 
				if(ulim>=0)	tulim=ulim;
				if(ulim<0)
				{	
					p=ulim;
					q=ulim-p;
					if(q!=0)p=ulim-1;
					else p=ulim;
					tulim=p;
				}
				if(llim>0)
				{	
					p=llim;
					q=llim-p;
					if(q!=0)p=llim+1;
					else p=llim;
					tllim=p;
				}
				if(llim<=0)	tllim=llim;
				parent[comp] = irange_ran(tllim,tulim);

			}
			check =parent[comp];
			temp = (flip() == TAIL) ? 
			    -get_F(T,t,parent[comp]-llim,B,2)
			    :get_F(T,t,ulim-parent[comp],B,2);
			parent[comp]=(int)(parent[comp]+temp);
		}
		else if(arri[comp]==3)
			parent[comp] = (flip() == TAIL) ? 0 : 1;

		else
		{
			if((parent[comp]<llim)||(parent[comp]>ulim))
				parent[comp] = frange_ran(llim,ulim);
			parent[comp] = (flip() == TAIL) ? 
			    parent[comp]-get_F(T,t,parent[comp]-llim,B,1) :
			    parent[comp]+get_F(T,t,ulim-parent[comp],B,1);
		}
       condit = satis_con(parent, fin_mat, rc);
       if(!condit)  /*return to the calling function to reselect a parent*/
         break;

	}
  free_ivector(next,1);
  return (condit);
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   oper7()                                      */
/*                                                                              */
/*           SYNOPSIS          :   void oper7(p1,p2,rc,fin_mat,X,x2)            */
/*                                                                              */
/*           DESCRIPTION       :   This function returns one new vector         */
/*                                                                              */
/*           FUNCTIONS CALLED  :   frange_ran()                                 */
/*                                 vector(),                                    */
/*                                 satis_con()                                  */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void oper7(VECTOR p1,VECTOR p2,INDEX rc,MATRIX fin_mat,IVECTOR arri)
/*The two parents for crossing over*/
/*Row and column of the final matrix*/
/*The final matrix*/
{
	VECTOR child;
	FLAG _CHECK = FALSE;
	int i,n=2,tries=10,p;
	float A;

	child = vector(1,rc.c-2);

	do
	{
		A = frange_ran(0.0,1.0);
		for(i=1; i<=rc.c-2; i++)
		{
			if(arri[i]==2)
			{
				child[i]=p2[i]+irange_ran(0,(p2[i]-p1[i]));
				child[i]=(int)child[i];
			}
			if(arri[i]==3)
				child[i] = (flip() == TAIL) ? 0 : 1;
			if(arri[i]==1)
				child[i]=A*(p2[i]-p1[i])+p2[i];
		}
		_CHECK = satis_con(child,fin_mat,rc);
		n++;

	}while((n<=tries) && (_CHECK == FALSE));

	if (_CHECK)
		for(i=1; i<=rc.c-2; i++)
		{        
			p1[i] = child[i];
		}
	free_vector(child,1);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   satis_con()                                  */
/*                                                                              */
/*           SYNOPSIS          :   FLAG satis_con(child,fin_mat,rc)             */
/*                                                                              */
/*           DESCRIPTION       :   This function returns TRUE or FALSE depending*/
/*                                  on whether the vector passed satisfies all  */
/*                                  the constraints or not.                     */
/*                                                                              */
/*           FUNCTIONS CALLED  :   none()                                       */
/*                                                                              */
/*           CALLING FUNCITONS :   oper5()                                      */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/
FLAG satis_con(VECTOR child,MATRIX fin_mat,INDEX rc)
/*The vector to be checked for violation of constriants*/
/*The final matrix*/
/*Row and column of the final matrix*/
{
	int i,j;
	float tot;


	for(j=1; j<=rc.c-2; j++)
		if((child[j] > fin_mat[j][rc.c]) || (child[j] < fin_mat[j][1]))
			return(FALSE);

	/*Substitute the values for all the variables, with the new values of*/
	/*the vector passed and check if the limits are crossed*/
	for(j=1; j<=rc.r; j++)
	{
		tot = 0.0;
		for(i=2; i<=rc.c-1; i++)
			tot = tot + fin_mat[j][i] * child[i-1];

		/*If the limits are crossed, return FALSE*/
		if((tot < fin_mat[j][1]) || (tot > fin_mat[j][rc.c]))
			return(FALSE);
	}

	/*If the limits are not crossed, return TRUE*/
	return(TRUE);
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_range()                                 */
/*                                                                              */
/*           SYNOPSIS          :   void find_range(llim,ulim,comp,fin_mat,rc    */
/*                                                                         X,x2)*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the upper and lower      */
/*                                  limits, within which the mutation should    */
/*                                  occur.                                      */
/*                                                                              */
/*           FUNCTIONS CALLED  :   none()                                       */
/*                                                                              */
/*           CALLING FUNCITONS :   oper1()                                      */
/*                                 oper2()                                      */
/*                                 oper3()                                      */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void swaper(float *a,float *b)
{  
	float c;
	c=*b;
	*b=*a;
	*a=c;
}

void find_range(float *llim,float *ulim,int comp,MATRIX fin_mat,INDEX rc,VECTOR parent)
/*Upper and lower limits*/
/*Component of the vector to be mutated*/
/*Row and column of the final matrix*/
/*The final matrix*/
/*The vector with the values of the variables*/
{
	int i,j;
	float tot,templ,tempu,temp;
	FLAG _CHANGE=FALSE;

	/*Replace the values of the variables, and for the values of the vectors*/
	/*except the one which is to be mutated*/
	/*Find the lower and upper limits within which the mutation component's*/
	/*value should be found*/
	for(j=1; j<=rc.r; j++)
		if(fin_mat[j][comp+1] != 0.0)
		{
			tot = 0.0;
			for(i=2; i<=rc.c-1; i++)
				if(i!=comp+1)
					tot = tot + fin_mat[j][i] * parent[i-1];

			templ = (fin_mat[j][1] - tot) / fin_mat[j][comp+1];
			tempu = (fin_mat[j][rc.c] - tot) / fin_mat[j][comp+1];

			if(fin_mat[j][comp+1]<0)
				swaper(&templ,&tempu);

/*			if(templ > tempu)
				swap(&templ,&tempu);
*/

			if(!_CHANGE)
			{
				*llim = templ;
				*ulim = tempu;
				_CHANGE = TRUE;
			}
			else
			{
				if(*llim < templ)
					*llim = templ;
				if(*ulim > tempu)
					*ulim = tempu;
			}
		}
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   irange_ran()                                 */
/*                                                                              */
/*           SYNOPSIS          :   int irange_ran(llim,ulim)                    */
/*                                                                              */
/*           DESCRIPTION       :   This function returns a random integer       */
/*                                  between the llim and ulim.                  */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   find_parent(),                               */
/*                                 oper1().                                     */
/*                                 oper2().                                     */
/*                                 oper3().                                     */
/*                                 oper5().                                     */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   10/21/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/
int irange_ran(int llim,int ulim)
{
	int num,diff;

	if(llim>ulim)
	{
		int k=llim;
		llim = ulim;
		ulim =k;
	}
	diff = ulim - llim;
	if(diff<2) return ((flip()==TAIL)?llim:ulim);
	do
		num =  llim + ((int) ((newrand()*(long)(ulim-llim+1))/(long) 65535));
	while ((num < llim) || (num > ulim));
	return(num);
}



/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   get_F()                                      */
/*                                                                              */
/*           SYNOPSIS          :   float get_F(T,t,y,B)                         */
/*                                                                              */
/*           DESCRIPTION       :   This function returns the float value which  */
/*                                  is the evaluated value of the function,     */
/*                                  needed for the operators 3 and 6            */
/*                                                                              */
/*           FUNCTIONS CALLED  :   none()                                       */
/*                                                                              */
/*           CALLING FUNCITONS :   oper3()                                      */
/*           CALLING FUNCITONS :   oper6()                                      */
/*                                                                              */
/*           AUTHOR            :   Tom Logan                                    */
/*                                                                              */
/*           DATE              :   2/23/93                                      */
/*                                                                              */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

float get_F(unsigned long T,unsigned long t,float y,int B,int k)
{
	float factor;
	int p;
	factor =  (float) pow(1.0 - (float)t/(float)T,(float)B);
	if (k==1)
	{  	
		factor = factor * frange_ran(0.0,1.0);
		if (factor < 0.00001)factor = 0.00001;
		if(factor>1)factor =1;
		return(y * factor);
	}
	else if (k==2)
	{
		if (factor < 0.00001)factor = 0.00001;
		if(factor>1)factor =1;
		p=irange_ran(0,y*factor);
		return(p);
	}
}
