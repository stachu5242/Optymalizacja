#include<stdlib.h>
#include<math.h>
#include <stdio.h>
#include<time.h>
#include<string.h>
#include <ctype.h>

#define TRUE 1
#define FALSE 0

#define DOS_SYS  FALSE           /* set to true for dos, false for unix */
#define UNIX_SYS TRUE            /* set to true for unix, false for dos */

#define flip()  ((int) ((newrand()*(long)2)/(long) 65535))
#define MIN -32768
#define MAX 32768
#define BIGINT 100000000
#define HEAD 1
#define TAIL 0
#define TRIES 10000
#define MAX_VAR 25
#define MULT 25173
#define INCR 13849
#define MOD ((long int) 65536)
#define SHUFFLE 256   /* size of random number shuffle array */
#define EST_OFFSET 0  /* offset in hours from Eastern Standard Time zone)  */

typedef float **MATRIX;
typedef float *VECTOR;
typedef int **IMATRIX;
typedef int *IVECTOR;
typedef int FLAG;
typedef int TOSS;
typedef struct {int r; int c;}INDEX;

#if UNIX_SYS
  FILE *input,*output;
  int   test_num;
  unsigned long count_gener;
  long rseed;
  unsigned int rand_array[SHUFFLE];
#endif

float **matrix(int,int,int,int);
float *vector(int,int);

float det(MATRIX ,int);
float evaluate(VECTOR);
float frange_ran(float,float);
float get_F(unsigned long,unsigned long,float,int,int);
float x_pow_y(float,int);

FLAG oper1(VECTOR ,MATRIX,INDEX,IVECTOR);
FLAG oper2(VECTOR ,MATRIX,INDEX,IVECTOR);
FLAG oper3(VECTOR ,MATRIX,INDEX,unsigned long,unsigned long,int,IVECTOR);
void oper4(VECTOR ,VECTOR,int,IVECTOR,INDEX,MATRIX);
void oper5(VECTOR,VECTOR,int,INDEX,MATRIX,IVECTOR);
FLAG oper6(VECTOR , MATRIX,INDEX,unsigned long,unsigned long,int,IVECTOR);
void oper7(VECTOR,VECTOR,INDEX,MATRIX,IVECTOR);

int **imatrix(int,int,int,int);
int *ivector(int,int);

unsigned long factorial(int);
int find_sum(IVECTOR,int);
int irange_ran(int,int);
int p_equalities(MATRIX ,IVECTOR ,IVECTOR ,int ,int *);
int x_power_y(int,int);

FLAG initialize_x2(MATRIX,INDEX,IVECTOR,IVECTOR,int,VECTOR,VECTOR,IVECTOR);
FLAG satis_con(VECTOR ,MATRIX ,INDEX);

void assign_probab(VECTOR,int,double);
void bi_deci(IMATRIX,IMATRIX,int,int);
void change_coeff();
void copy_matrix(MATRIX,MATRIX,int,int,int,int);

void find_X(MATRIX,VECTOR,VECTOR,int,int,IVECTOR,IVECTOR,VECTOR);
void find_ac1_ac2(int,int,int,IVECTOR,IVECTOR,MATRIX,MATRIX,MATRIX);
void find_cum_probab(VECTOR,VECTOR,int);
void find_final_mat1(VECTOR,VECTOR,MATRIX,int,int);
void find_final_mat2(MATRIX,int,int,int,MATRIX);
void find_final_mat3(MATRIX,int,int,int,MATRIX);
void find_limits(int,MATRIX,VECTOR,VECTOR);
void find_lu1_lu2(int *,IVECTOR,IVECTOR,VECTOR,VECTOR,VECTOR);
void find_new_in_eq(VECTOR,float**,VECTOR,VECTOR,INDEX,MATRIX);
void find_org_in_eq(VECTOR,float**,VECTOR,MATRIX,MATRIX,int,INDEX,MATRIX);
void find_probability(int,int,int,IMATRIX);
void find_range(float *,float *,int,MATRIX,INDEX,VECTOR);
void find_x1_x2(int,IMATRIX,IVECTOR,IVECTOR);

void free_vector(VECTOR,int);
void free_ivector(IVECTOR,int);
void free_matrix(float**,int,int,int);
void free_imatrix(IMATRIX,int,int,int);

void get_var_order(IVECTOR,IVECTOR,IMATRIX,IVECTOR);
void inverse(MATRIX,MATRIX,int);
void initialize(MATRIX,INDEX);
void mmprod(int,int,int,MATRIX,MATRIX,MATRIX);
void mvprod(int,int,float*,MATRIX,VECTOR);
void nrerror(char *);

void optimization(VECTOR,IVECTOR,IVECTOR,MATRIX,INDEX,int,VECTOR,int,IVECTOR);
void print_domains(MATRIX,int);
void print_equalities(MATRIX,int,int,IVECTOR,VECTOR);
void print_inequalities(MATRIX,int,int,IVECTOR,VECTOR);
void print_ivector(IVECTOR,int,int);
void print_matrix(int ,int ,int ,int ,MATRIX );
void print_population(int,int ,MATRIX );
void print_vector(VECTOR,int,int);

FLAG feasible();

void read_file(MATRIX,MATRIX,MATRIX,IVECTOR,IVECTOR);
void rem();
void seed();
void sort(int,MATRIX,int);
void swap(float**, float**);
void swaper(float*, float*);
void write_file(MATRIX,INDEX,VECTOR,IVECTOR,IVECTOR,int,int,int );
void find_live(VECTOR,IVECTOR,int,int);
int  find_die(VECTOR,IVECTOR,int);
int find_parent(IVECTOR,int);
unsigned int newrand();
unsigned int randint();

