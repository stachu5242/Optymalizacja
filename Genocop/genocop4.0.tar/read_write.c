#include "genocop.h"

#if DOS_SYS
  extern FILE *input,*output;
#endif


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   read_file()                                  */
/*                                                                              */
/*           SYNOPSIS          :   void read_file(equalities,inequalities,      */
/*                                                              domains,tot_arr)*/
/*                                                                              */
/*           DESCRIPTION       :   This function reads from an input file the   */
/*                                  data and writes on the the corresponding    */
/*                                  equalities, inequalites and domain matrices */
/*				    and the integer and boolean variable 
*/
/*				    information.
*/
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   main()                                       */
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani
*/
/*                                                                              */
/*           DATE              :   21/10/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/


void read_file(MATRIX equalities,MATRIX inequalities,MATRIX domains,IVECTOR tot_arr,IVECTOR arri)
{
  int t2,i,j,total_variables;
  float t1,t3;
int che=0,cnt=1;
int q;int k;int temp;

  rem();
  if(tot_arr[1] != 0)
  {    for(i=1; i<=tot_arr[1]; i++)
       for(j=1; j<=tot_arr[0] + 1; j++)
       {	k= fscanf(input," %f",&equalities[i][j]);
		if(k==0)
	{printf("\nError : while scanning equalities from input file.\n\n");
		fclose(input);
		fclose(output);
		exit(0);
	}
	}

  }
 

	rem();
  if(tot_arr[2] != 0)
   { 	 for(i=1; i<=tot_arr[2]; i++)
      	 for(j=1; j<=tot_arr[0]+1; j++)
         {	k=fscanf(input," %f",&inequalities[i][j]);
		if(k==0)
	{printf("\nError : while scanning inequalities from input file.\n\n");
		fclose(input);
		fclose(output);
		exit(0);
	}
	}
   }

for(i=1; i<=tot_arr[0]; i++)
    {
      domains[i][1] = MIN;
      domains[i][2] = (float) i;
      domains[i][3] = MAX;
    }

	rem();
    if(tot_arr[3] != 0)
    for(i=1; i<=tot_arr[3]; i++)
      {
        k=fscanf(input," %f %d %f",&t1,&t2,&t3);
	if(k==0)
	{printf("Error : while scanning domains from input file.\n");
		fclose(input);
		fclose(output);
		exit(0);
	}
        domains[t2][1] = t1;
        domains[t2][3] = t3;
      }

	rem();


/*  We store 1 for real , 2 for integer and 3 for a boolean in arri[variable]*/
for(q=1;q<=tot_arr[0];q++)
arri[q]=1;

cnt=1;
che=0;
if(tot_arr[4]==0)
	fscanf(input,"%d",&k);
else
{ while(che==0)
  {	k=fscanf(input,"%d",&temp);
	if(k==0)
	{printf("\nError : while scanning integers from input file.\n\n");
		fclose(input);
		fclose(output);
		exit(0);
	}

	if(temp==0)
	che=1;

	if(cnt==1)
	{	if(temp<0)
		{	for(q=1;q<=tot_arr[0];q++)
			{arri[q]=2;}
			che=1;
		}
	}

	if(che==0)	arri[temp]=2;

	if(cnt>tot_arr[0])
	{
printf("\nError : In input file while entering integers...\n\n");
	 exit(12);
	}	
	cnt++;
   }
}

	rem();
che=0;
cnt=1;

if(tot_arr[5]==0)
	fscanf(input,"%d",&k);
else
{  while(che==0)
   {	
	k=fscanf(input,"%d",&temp);
	if(k==0)
	{printf("\nError : while scanning booleans from input file.\n\n");
		fclose(input);
		fclose(output);
		exit(0);
	}

	if(temp==0)
	che=1;

	if(cnt==1)
	{	if(temp<0)
		for(q=1;q<=tot_arr[0];q++)
		{arri[q]=3;che=1;}
	}
	if(che==0) arri[temp]=3;

	if(cnt>tot_arr[0])
	{
printf("\nError : In input file while entering booleans...\n\n");
	 exit(12);
	}	
	cnt++;
   }
}
   printf("Variable types are [r-real : i-int : b-bool] : \n");
  fprintf(output,"Variable types are [r-real : i-int :b-bool] : \n");
   for(k=1;k<=tot_arr[0];k++)
   {  	
	if(arri[k]==1)
	{	printf("r ");
 		fprintf(output,"r ");
	}
	else if(arri[k]==2)
	{	printf("i ");
 		fprintf(output,"i ");
	}
	else
	{	printf("b ");
 		fprintf(output,"b ");
	}
   }
printf("\n");
fprintf(output,"\n");

}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   write_file()                                 */
/*                                                                              */
/*           SYNOPSIS          :   void write_file(final_mat,fin_row,fin_col,   */
/*                                                     a1_b,x1,x2,x1_row,x2_row)*/
/*                                                                              */
/*           DESCRIPTION       :   This function writes on to an output file the*/
/*                                  converted equalities, inequalites and       */
/*                                  the domains, represented with the           */
/*                                  uneliminated varables, in the format        */
/*                                  requested                                   */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   main()                                       */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/


void write_file(MATRIX final_mat,INDEX fin,VECTOR a1_b,IVECTOR x1,IVECTOR x2,int x1_row,int x2_row,int in)
{
  int i,j,k=1;

  fprintf(output,"Left\t\t");
  for(j=1; j<=fin.c-2; j++)
    fprintf(output," X%d\t",x2[j]);
  fprintf(output,"\tRight\n");


  for(i=1; i<=fin.r; i++)
    {
      for(j=1; j<=fin.c; j++)
        {
          if (((j==2)&&(i<in))||(j==fin.c))
            fprintf(output,"\t");
          fprintf(output,"%5.2f\t",final_mat[i][j]);
        }
      fprintf(output,"\n");
    }

  fprintf(output,"\n\n\n\n\t");


  for(j=1; j<=fin.c-2; j++)
    fprintf(output," X%d\t",x2[j]);
  fprintf(output,"const\n\n");


  for(i=x2_row+1; i<=x2_row+x1_row; i++)
    {
      fprintf(output,"X%d\t",x1[k]);
      for(j=2; j<fin.c; j++)
        fprintf(output,"%5.2f\t",final_mat[i][j]);
      fprintf(output,"%5.2f\n",a1_b[k++]);
    }
}


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   rem()                                 */
/*                                                                              */
/*           SYNOPSIS          :   void rem()   
*/
/*                                                                              */
/*           DESCRIPTION       :  This function removes the comments from the 
*/
/*				  input file . It checks for any errors that  
*/
/*				  the user may have given in the input file.
*/
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   main() ,                                     */
/*				   read_file() ,
*/
/*				   optimization() .
/*                                                                              */
/*           AUTHOR            :   Sunil Reddy Talusani                      
*/
/*                                                                              */
/*           DATE              :   21/10/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void rem()
{
	char a,b;
	char *tmp;
	tmp = (char *)malloc (100);
	do{
	a=getc(input);
	}while(a!='/');
	b=getc(input);
	if((a=='/')&&(b=='*'))	/*Ignore text between comments.*/
	{	do
		{	a=b;
			b=getc(input);
 		}while(!((a=='*')&&(b=='/')));
	}
	else 	/*Else print and error occured.*/
	{
	printf("\n\n");
	printf("Error in separating input file and remaining file is :");
		tmp=fgets(tmp,90,input);
		printf("%s\n",tmp); 
		tmp=fgets(tmp,90,input);
		printf("%s\n",tmp); 
		fclose(input);
		fclose(output);
		exit(12);
	}
}	
 
