#include "genocop.h"

#define	FILTER_ORDER  3
#define WINDOW_LENGTH 100

#define NORMALISING_FACTOR 0.596165
#define DB_OFFSET 50

#define INPUT_FILENAME "x_impulse"
#define OUTPUT_FILENAME "y_unknown"

float evaluate(coeff)
VECTOR coeff;
{
	FILE *ifp, *ofp, *fopen();
	int i, j, l, m; 
	int k_index, c_index;
	static int read_data = 0;
	static float x[WINDOW_LENGTH], unknown_y[WINDOW_LENGTH];
	float y[WINDOW_LENGTH];
        float db, log10();
	float sum, temp, past[FILTER_ORDER+1], c[FILTER_ORDER+1], difference; 

	/*  Read in the input and unknown system impulse response the
	    first time the function is called.                          */
  switch (test_num)
   {
   case 1:
	if (!read_data)
	{
		/*  Open the input file for reading  */
		if ((ifp = fopen(INPUT_FILENAME, "r")) == NULL)
			printf("error opening file");

		/*  Initialise array subscript to x[0]  */
		i = 0;

		/*  Read in another input value  */
		while (fscanf(ifp,"%f",&temp) != EOF)
			x[i++] = temp;

		/*  Close the input file  */
		fclose(ifp);

		/*  Open the impulse response file for reading  */
		if ((ofp = fopen(OUTPUT_FILENAME, "r")) == NULL)
			 printf("error opening file");

		/*  Initialise array subscript to y[0]  */
		i = 0;

		/*  Read in impulse reponse of unknown system  */
		while (fscanf(ofp,"%f",&temp) != EOF)
			unknown_y[i++] = temp;

		/*  Close the input response file  */
		fclose(ofp);

		/*  Read these files only once  */
		read_data = 1;
	}

	/*  Initialise past values and fitness value  */
	for (j = 0; j < (FILTER_ORDER+1); j++)
		past[j] = 0;

	difference = 0;

	/*  For each input value calculate the corresponding output  */
	for (i = 0; i < WINDOW_LENGTH; i++)
	{
		/*  Set sum initially to filter input at time i  */
		sum = x[i];

		/*  Calculate feedback components for each filter section  */
		for (l = FILTER_ORDER; l >= 1; l--) 
		{		
			k_index = l;

			sum = sum - (coeff[k_index] * past[l-1]);
			past[l] = past[l-1] + (coeff[k_index] * sum);
		}

		/*  Save past values  */
		past[0] = sum;

		y[i] = 0;

		/*  Calculate feedforward components for each filter section  */
		for (l = 0; l <= FILTER_ORDER; l++)
		{
			c_index = 1 + FILTER_ORDER + l;
			
			y[i] = y[i] + (coeff[c_index] * past[l]);
		}

		/*  Sum of squares  */
		difference += (unknown_y[i] - y[i]) * (unknown_y[i] - y[i]);
	}

        db = (10*log10(difference/NORMALISING_FACTOR)) + DB_OFFSET;

        if (db < 0) db = 0;

	return (db);
     default: printf("Invalid test case in eval.c - test case is %f", test_num);
              exit(0);
   }
  return(0);

}
