#include "thesis.h"


void mmprod(m,nm,n,mul_cm,mul_am,mul_bm)
int m,           
    nm,          
    n;           
MATRIX mul_cm,   
       mul_am,   
       mul_bm;   
{
 int i,j,k;      

 for(i= 1; i<=m; i++)
  for(j = 1; j<=n; j++)
   {
     mul_cm[i][j] = 0.0;
     for (k= 1;k<nm+1;k++)
       mul_cm[i][j] = mul_am[i][k]*mul_bm[k][j]  + mul_cm[i][j];
    }
}




void mvprod(m,nm,cm,am,bm)
int m,      
    nm;     
VECTOR cm,  
       bm;  
MATRIX am; 
{
int i,k;   

 for (i = 1; i<=m; i++)
  {
   cm[i]=0.0;
   for (k = 1; k<=nm; k++)
    cm[i] = cm[i] + am[i][k]*bm[k];
  }
}

