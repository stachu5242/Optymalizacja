#include "thesis.h"

void seed()
{
  int stime;
  long ltime;

  ltime = time(NULL);
  stime = (unsigned int) ltime;
  srand(stime);
}


float frange_ran(llim,ulim)
float ulim,llim;
{               
  float num,num1; 
  int diff;

  if(llim == ulim)
        return(llim);

    diff = (int)ulim - (int)llim;

    if( diff == 0)
          num = (int)llim;
    else
          num = llim + (rand() % diff);

  if(ulim - llim < 0.0001)
    return((flip() == TAIL) ? llim : ulim);

  do{
      num1 = num + (float) rand()/100000000000;
    }while((num1<llim)||(num1>ulim));

  return(num1);
}


FLAG initialize_x2(final,rc,x1,x2,x1_vari,X,a1_b)
MATRIX final;        
VECTOR X,a1_b;       
IVECTOR x1,x2;       
INDEX rc;            
int x1_vari;         
{
  int i,j,           
      x2_vari=rc.c-2,
      try=0;         
  FLAG _LOW,         
       _HIGH;        
  VECTOR temp;       
  MATRIX trymat;     
  float llim,ulim,sum;
  FLAG _CHECK;

  sum = 0.0;
  temp = vector(1,x2_vari);
  trymat = matrix(1,rc.r-x2_vari,0,x2_vari);

  do
    {
      if(try < TRIES)

	++try;
      for(i=1; i<=x2_vari; i++)

	temp[i] = frange_ran(final[i][1],final[i][rc.c]);

      if(x2_vari != rc.r)
	{ 
	  for(j=x2_vari+1; j<=rc.r; j++)
	    {
	      sum = 0.0;
	      for(i=1; i<=x2_vari; i++)

		sum  =  sum + temp[i] * final[j][i+1];


	      _LOW = (sum >= final[j][1]) ? TRUE : FALSE;
	      _HIGH = (sum <= final[j][rc.c]) ? TRUE : FALSE;
	      
	      if((!_LOW)||(!_HIGH))
		break;
 	    }
	}
      else
	_LOW = _HIGH = TRUE;     
    }while((try<TRIES) && ((!_LOW)||(!_HIGH)));
  if(try >= TRIES)
    {
      printf("Please input initial values\n",x1_vari+x2_vari);
      for(i=1; i<=x1_vari+x2_vari; i++)
	{
	  printf("\nX%d\t",i);
	  scanf("%f",&X[i]);
	}

      for(j=1; j<=rc.r; j++)
	{
	  sum = 0.0;
	  for(i=1; i<=x2_vari; i++)

	    sum  =  sum + X[x2[i]] * final[j][i+1];
	  

	  _LOW = (sum >= final[j][1]) ? TRUE : FALSE;
	  _HIGH = (sum <= final[j][rc.c]) ? TRUE : FALSE;
	  
	  if((!_LOW)||(!_HIGH))
	    {
	      printf("The input values do not satisfy the constraints\n%d\n",j);
	      exit(1);
	    }
	}
    }
  else
    if(x1_vari != 0)
      {
	for(i=1; i<=x2_vari; i++)
	  X[x2[i]] = temp[i];

	for(j=1; j<=x1_vari; j++)
	  {
	    X[x1[j]] = a1_b[j];
	    for(i=1; i<=x2_vari; i++)
	      X[x1[j]] = X[x1[j]] + temp[i] * final[j+x2_vari][i+1];
	  }
      }
    else
      {
	for(i=1; i<=x2_vari; i++)
	  X[i] = temp[i];
      }
  
  free_vector(temp,1,x2_vari);
  free_matrix(trymat,1,rc.r-x2_vari,0,x2_vari);
}

