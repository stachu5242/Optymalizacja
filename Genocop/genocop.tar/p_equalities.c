#include "thesis.h"


int p_equalities(equal,t_var,cart,cart_count,tot_combi)
MATRIX equal;     
IVECTOR t_var,    
        cart;     
int cart_count,*tot_combi;
{
  MATRIX p_equal; 
  int i,j,k,l,    
      p,          
      tot,        
      t_cart;     
  IMATRIX cartesian;
  IVECTOR index;    
  char status = 'f';
  MATRIX det_arr;   
  float d;          

  p  = t_var[1];
  tot = t_var[0];
  t_cart = (int) (factorial(tot)/(factorial(tot - p) * factorial(p)));

  cartesian = imatrix(1,t_cart,1,p);

  find_probability(p,tot,t_cart,cartesian);

  index = ivector(1,p);
  det_arr = matrix(1,p,1,p);
  p_equal = matrix(1,p,1,p);

  l = cart_count;

  while((status == 'f') && (l < t_cart))
    {
      for(i=1; i<=p; i++)
	for(j=1; j<=p; j++)
	    p_equal[i][j] = equal[i][cartesian[l][j]];

      l = l + 1;

      copy_matrix(p_equal,det_arr,1,p,1,p);
      d = det(det_arr,p);

      if(d != 0.0)
	{
	  status = 't';
	  l = l - 1;
	  for(i = 1; i<=p; i++)
	    cart[i] = cartesian[l][i];
	}
    }
  if(status == 'f')
    {
      fprintf(output,"The equations do not converge\n");
      exit(0);
    }

  *tot_combi = t_cart;

  free_imatrix(cartesian,1,t_cart,1,p);
  free_ivector(index,1,p);
  free_matrix(det_arr,1,p,1,p);
  free_matrix(p_equal,1,p,1,p);

  return(l);
}



void bi_deci(prob10,prob,t_cart,tot)
IMATRIX prob10,prob;
int tot,t_cart;
{
  int i,j,k;

  for(i=1; i<=t_cart; i++)
    {
      k = 1;
      for(j=1; j<=tot; j++)
	if(prob10[i][j] == 1)
	  prob[i][k++] = j;
    }
}
