#include "thesis.h"

void print_equalities(equal,t_var,t_equ,coeff,rhs)
MATRIX equal;      
VECTOR rhs;        
int t_var,         
    t_equ;         
IVECTOR coeff;     
{
  int i,j,flag = 0;

  fprintf(output,"\n\nEQUALITIES :\n");

  for(i=1; i<=t_equ; i++)
    {
      flag = 0;
      for(j=1; j<=t_var+1; j++)
	{
	  if((flag == 0)&&(equal[i][j] != 0.0))
	    {
	      fprintf(output," %3.2fX%d",equal[i][j],coeff[j]);
	      flag = 1;
	    }
	  else if(j == t_var + 1)
	    fprintf(output,"  =  %3.2f\n",rhs[i]);
	  else if(equal[i][j] < 0.0)
	    fprintf(output," - %3.2fX%d",fabs(equal[i][j]),coeff[j]);
	  else if(equal[i][j] > 0.0)
	    fprintf(output," + %3.2fX%d",fabs(equal[i][j]),coeff[j]);
	}
    }      
}



void print_inequalities(equal,t_var,t_equ,coeff,ineq_rhs)
MATRIX equal;    
VECTOR ineq_rhs; 
int t_var,       
    t_equ;       
IVECTOR coeff;   
{
  int i,j,flag = 0;

  fprintf(output,"\n\nINEQUALITIES :\n");

  for(i=1; i<=t_equ; i++)
    {
      flag = 0;
      for(j=1; j<=t_var+1; j++)
	{
	  if((flag == 0)&&(equal[i][j] != 0.0))
	    {
	      fprintf(output," %3.2fX%d",equal[i][j],coeff[j]);
	      flag = 1;
	    }

	  else if(j == t_var + 1)
	    fprintf(output," <=  %3.2f\n",ineq_rhs[i]);
	  else if(equal[i][j] < 0.0)
	    fprintf(output," - %3.2fX%d",fabs(equal[i][j]),coeff[j]);
	  else if(equal[i][j] > 0.0)
	    fprintf(output," + %3.2fX%d",fabs(equal[i][j]),coeff[j]);
	}
    }      
}



void print_domains(equal,t_equ)
MATRIX equal;  
int t_equ;     
{
  int i,j,temp;

  fprintf(output,"\n\nDOMAINS :\n");

  for(i=1; i<=t_equ; i++)
    {
      for(j=1; j<=3; j++)
	{
	  if(j == 2)
	    fprintf(output,"  <=  X%-2d  <=   ",(int)equal[i][j]);
	  else 
	    fprintf(output," %3.2f ",equal[i][j]);
	}
      fprintf(output,"\n");
    }      
}

