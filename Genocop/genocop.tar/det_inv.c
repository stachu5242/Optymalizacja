#include "thesis.h"


void inverse(a,a_inverse,n)
MATRIX a,a_inverse;    
int n;                 
{
 int i,j,k,k1,l,l1,n1; 
 float d1,             
       v,w;
 MATRIX b;             

 b = matrix(1, n, 1, n);
 for(i=1; i<=n; i++)
   for(j=1; j<=n; j++)
    b[i][j] = 0.0;

 d1 = det(a, n);

 if(d1==0.0) printf("No inverse exists");
 else
 {
   v=-1.0;
   for(i=1;i<=n;i++)
    {
      v=-v;
      w=-1.0;
	for(j=1;j<=n;j++)
	 {
	   w=-w;
	   n1=n-1;
	     for(k=1;k<=n1;k++)
	      {
		k1=k;
		if(k>=i) k1=k+1;
		  for(l=1;l<=n1;l++)
		   {
		     l1=l;
		     if(l>=j) l1=l+1;
		     b[k][l]=a[k1][l1];
		   }
	      }
	       a_inverse[j][i]=det(b,n1)/d1*v*w;
	 }
    }
 }
 free_matrix(b,1,n,1,n);
}


float det(input_matrix, nl)
MATRIX input_matrix; 
int nl;              
{
 int ia,ib,i1,j1,n2,nz,n3,l,l1,m,m1;
 float d,x;
 MATRIX temp_input_matrix,b1;

 temp_input_matrix = matrix(1,nl,1,nl);
 b1 = matrix(1,nl,1,nl);

 for(i1=1;i1<=nl;i1++)
  for(j1=1;j1<=nl;j1++)
   temp_input_matrix[i1][j1]=input_matrix[i1][j1];

 d=1.0;
 for(ia=1;ia<=nl;ia++)
  {
   x=-1.0;
   n2=nl-ia+1;
     n3=n2-1;
   nz=0;
   for(ib=1;ib<=n2;ib++)
    if(temp_input_matrix[ib][1]!=0.0) nz=ib; 
   if(nz==0.0) d=0.0;
   else
    {
     for(i1=1;i1<=nz;i1++)
      x=-x;
     d*=temp_input_matrix[nz][1]*x;        

     for(l=1;l<=n3;l++)
      {
       l1=l;
       if(l>=nz) l1=l+1;
       for(m=1;m<=n3;m++)
	{
	 m1=m+1;
	 b1[l][m] = temp_input_matrix[l1][m1] - temp_input_matrix[l1][1]
		    /temp_input_matrix[nz][1]*temp_input_matrix[nz][m1];
       }
     }
   }     
     for(i1=1;i1<=n3;i1++)
       for(j1=1;j1<=n3;j1++)
	 temp_input_matrix[i1][j1]=b1[i1][j1];

 }
 free_matrix(b1,1,nl,1,nl);
 free_matrix(temp_input_matrix,1,nl,1,nl);
 
 return(d);
 }
