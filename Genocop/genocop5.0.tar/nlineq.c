/****************************************************************************
***
***
*** NLINEQ.C
***
*** NOTE:
***
*** This is where you enter the non-linear inequalitie(s).  Choose
*** correct case numbers and remember to insert the 'break;' statement at
*** the end of each case.  Also, mind the semicolon after each function
*** line.  All functions are of the form nlineq[i] = f(X[1], X[2],...,X[n]);
***
*** The core data structure variable EVOLDATA ev (see the file GENOCOP.H)
*** is available at this point.  You may access any of the variables
*** in this structure, but DO NOT CHANGE THEM or the code won't
*** work.
***
*** If you wish to use additional variables, they MUST be declared
*** in the file VALIDATE.C, in the function in which this file
*** (NLINEQ.C) is physically inserted during compilation time.
*** If you're not sure what this means, you probably shouldn't try it.
***
*** Also, some compilers won't flag declarations inside included files
*** as an error (esp. C++ compilers), but the CODE WON'T WORK.
***
***************************************************************************/



			
	case 5:
		nlineq[1] = X[1] + X[2] - X[3] - 1.0;
		nlineq[2] = -1.0*X[1] + X[2] - X[3] + 1.0;
		nlineq[3] = 12.0*X[1] + 5.0*X[2] + 12.0*X[3] - 34.8;
		nlineq[4] = 12.0*X[1] + 12.0*X[2] + 7.0*X[3] - 29.1;
		nlineq[5] = -6.0*X[1] + X[2] + X[3] + 4.1;
		break;
		
	case 901:
		nlineq[1] = 2.0*(X[1] + X[2]) + X[10] + X[11] - 10.0;		
		nlineq[2] = -8.0*X[1] + X[10];		
		nlineq[3] = -2.0*X[4] - X[5] + X[10];		
		nlineq[4] = 2.0*(X[1] + X[3]) + X[10] + X[12] - 10.0;		
		nlineq[5] = -8.0*X[2] + X[11];		
		nlineq[6] = -2.0*X[6] - X[7] + X[11];				
		nlineq[7] = 2.0*(X[2] + X[3]) + X[11] + X[12] - 10.0;		
		nlineq[8] = -8.0*X[3] + X[12];		
		nlineq[9] = -2.0*X[8] - X[9] + X[12];
		break;
		
	case 902:
		for(i = 1, nlineq[1] = 1.0; i <= 20; i++)
			nlineq[1] *= X[i];
		nlineq[1] = 0.75 - nlineq[1];
		for(i = 1, nlineq[2] = 0.0; i <= 20; i++)
			nlineq[2] += X[i];
		nlineq[2] -= 7.5 * 20;
		break;
		
	case 904:
		nlineq[1] = 85.334407 + 0.0056858*X[2]*X[5] + 0.0006262*X[1]*X[4] - 0.0022053*X[3]*X[5] - 92;
		nlineq[2] = 80.51249 + 0.0071317*X[2]*X[5] + 0.0029955*X[1]*X[2] + 0.0021813*X[3]*X[3] - 110;
		nlineq[3] = 9.300961 + 0.0047026*X[3]*X[5] + 0.0012547*X[1]*X[3] + 0.0019085*X[3]*X[4] - 25;		
		nlineq[4] = -1.0 * (85.334407 + 0.0056858*X[2]*X[5] + 0.0006262*X[1]*X[4] - 0.0022053*X[3]*X[5]);
		nlineq[5] = -1.0 * (80.51249 + 0.0071317*X[2]*X[5] + 0.0029955*X[1]*X[2] + 0.0021813*X[3]*X[3] - 90);
		nlineq[6] = -1.0 * (9.300961 + 0.0047026*X[3]*X[5] + 0.0012547*X[1]*X[3] + 0.0019085*X[3]*X[4] - 20);
		break;
		
	case 906:
		nlineq[1] = -1.0 * ( (X[1] - 5)*(X[1] - 5) + (X[2] - 5)*(X[2] - 5) - 100.0 );
		nlineq[2] = (X[1] - 6)*(X[1] - 6) + (X[2] - 5)*(X[2] - 5) - 82.81;
		break;
		
	case 907:
		nlineq[1] = -1.0 * (105 - 4*X[1] - 5*X[2] + 3*X[7] -9*X[8]) ;
		nlineq[2] = -1.0 * (-10*X[1] + 8*X[2] + 17*X[7] - 2*X[8]);
		nlineq[3] = -1.0 * (8*X[1] - 2*X[2] - 5*X[9] + 2*X[10] + 12);
		nlineq[4] = -1.0 * (3*X[1] - 6*X[2] - 12*(X[9] - 8)*(X[9] - 8) + 7*X[10]);		
		nlineq[5] = -1.0 * (-3*(X[1] - 2)*(X[1] - 2) - 4*(X[2] - 3)*(X[2] - 3) - 2*X[3]*X[3] + 7*X[4] + 120);		
		nlineq[6] = -1.0 * (-1.0*X[1]*X[1] - 2*(X[2] - 2)*(X[2] - 2) + 2*X[1]*X[2] - 14*X[5] + 6*X[6]);		
		nlineq[7] = -1.0 * (-5.0*X[1]*X[1] - 8*X[2] - (X[3] - 6)*(X[3] - 6) + 2*X[4] + 40);		
		nlineq[8] = -1.0 * (-0.5*(X[1] - 8)*(X[1] - 8) - 2*(X[2] - 4)*(X[2] - 4) - 3*X[5]*X[5] + X[6] + 30);
		break;
		
	case 908:
		nlineq[1] = X[1]*X[1] - X[2] + 1;
		nlineq[2] = 1 - X[1] + (X[2] - 4)*(X[2] - 4);
		break;
		
	case 909:
		nlineq[1] = -1 * (127 - 2*X[1]*X[1] - 3*X[2]*X[2]*X[2]*X[2] - X[3] - 4*X[4]*X[4] - 5*X[5]);
		nlineq[2] = -1 * (196 - 23*X[1] - X[2]*X[2] - 6*X[6]*X[6] + 8*X[7]);
		nlineq[3] = -1 * (282 - 7*X[1] - 3*X[2] - 10*X[3]*X[3] - X[4] + X[5]);
		nlineq[4] = -1 * (-4*X[1]*X[1] - X[2]*X[2] + 3*X[1]*X[2] - 2*X[3]*X[3] - 5*X[6] + 11*X[7]);
		break;
		
	case 910:
		nlineq[1] = -1 * (1 - 0.0025*(X[4] + X[6]));
		nlineq[2] = -1 * (1 - 0.01*(X[8] - X[5]));
		nlineq[3] = -1 * (X[2]*X[7] - 1250*X[5] - X[2]*X[4] + 1250*X[4]);
		nlineq[4] = -1 * (1 - 0.0025*(X[5] + X[7] - X[4]));
		nlineq[5] = -1 * (X[1]*X[6] - 833.33252*X[4] - 100*X[1] + 83333.333);
		nlineq[6] = -1 * (X[3]*X[8] - 1250000 - X[3]*X[5] + 2500*X[5]);
		break;

                       
/******* END OF FILE ******************************************************/



















