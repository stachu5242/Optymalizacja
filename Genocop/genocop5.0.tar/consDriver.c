#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv)
{
  FILE* fin = fopen("cons.in", "r");
  int runsPerFile;
  char files[256][256];
  char buf[256];
  char c;
  int i, j, fCount;
  
  if(argc != 2)	{
    printf("\nUsage - consDriver runsPerFile\nProgram exits!!\n\n");
    return 1;
  }
  runsPerFile = atoi(argv[1]);
  
  fCount = 0;
  while(1)	{    
    i = 0;
    while( (c = getc(fin)) != 0x0a)	{
      buf[i] = c;
      i++;
    }
    buf[i] = 0;
    strtok(buf, " \t");
    if( !strcmp(buf, "*END") )	break;
    strcpy(files[fCount], buf);
    fCount++;
  }
  fclose(fin); 

/*****  
  printf("The files:\n");
  for(i = 0; i < fCount; i++)	printf("  <%s>\n", files[i]);
*****/  

  system("rm mapTest.out");
  for(i = 0; i < fCount; i++)	{
    for(j = 0; j < runsPerFile; j++)	{
      printf("Begin run <%i> for file: <%s>\n", j + 1, files[i]);
      sprintf(buf, "genocop %s %s.out", files[i], files[i]);
printf("***test point 1000\n");  fflush(stdout);    
      system(buf);
printf("***test point 2000\n");  fflush(stdout);    
    }
  }
  
  sprintf(buf, "consTest %i %i", fCount, runsPerFile);
  system(buf);
  
  return 0;
}













