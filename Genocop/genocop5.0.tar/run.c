#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv)
{
  char buf[256];
  
  sprintf(buf, "genocop %s %s.out", argv[1], argv[1]);
  printf("%s\n", buf);
  system(buf);
  
  return 0;
}













