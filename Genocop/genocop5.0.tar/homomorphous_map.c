/***   Dave's Code!!  ***/

#include "genocop.h"

#if DOS_SYS
extern FILE *input,*output;
extern int test_num;
#endif

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   doHomomorphMap()                             */
/*                                                                              */
/*           SYNOPSIS          :   void doHomomorphMap(Xmapped,X,tot_vars,	*/
/*					true_ineqs,true_doms,r0, tot_ine,	*/
/*					upDoms, lowDoms)       			*/
/*                                                                              */
/*           DESCRIPTION       :   Performs homomorphous mapping between        */
/*					X and Xmapped				*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

#define		MAP_TEST1	0	/*  show X and ymax  */
#define		MAP_TEST2	0	/*  show scaledXVect  */
#define		MAP_TEST3	0	/*  show sVect  */
#define		MAP_TEST4	0	/*  show sLength  */
#define		MAP_TEST5	0	/*  show tVect  */
#define		MAP_TEST6	0	/*  show Xmapped  */

void doHomomorphMap(Xmapped,X,tot_vars,true_ineqs,true_doms,r0, tot_ine, upDoms, lowDoms)
MATRIX true_ineqs,true_doms;
VECTOR X,Xmapped,r0,upDoms,lowDoms;
int tot_vars, tot_ine;
{
  double ymax, sLength, deltaInvVal;
  int i, tCount, invalid, infeasible, oddCount, lastIsInvalid, boundaryIsInvalid, tempVld;
  VECTOR	sVect,	/**  boundary point  ***/
  		scaledXVect,
  		tempVect1,
  		tempVect2,
  		tempVect3,
  		tVect,	/** vector of feasible boundaries  **/
  		sMinus_r0Vect;
  
/***  find ymax  ****/
  ymax = fabs(X[1]);
  for(i = 2; i <= tot_vars; i++)	{
    if( fabs(X[i]) > ymax )	ymax = fabs(X[i]);
  }
#if(MAP_TEST1)
showVector(X, 1, tot_vars, "X");
printf("\nymax:  %f\n", ymax);	fflush(stdout);
#endif
  if(ymax < MAP_RESOLUTION)	{
    for(i = 1; i <= tot_vars; i++)	Xmapped[i] = r0[i];
    return;
  }
  
/*****   allocate stuff  ***/
  sVect = vector(1, tot_vars);  
  scaledXVect = vector(1, tot_vars);  
  tempVect1 = vector(1, tot_vars);  
  tempVect2 = vector(1, tot_vars);  
  tempVect3 = vector(1, tot_vars); 
  sMinus_r0Vect = vector(1, tot_vars); 
  tVect = 0;
  
/***  for(i = 1; i <= tot_vars; i++)X[i] = X[i] / MAX_CUBE_VAL;  ***/

/****  find scaledXVect  ***/
  vectorScalarMult(X, 1.0 / ymax, tot_vars, scaledXVect);
#if(MAP_TEST2)
showVector(scaledXVect, 1, tot_vars, "X / ymax");
putchar('\n');	fflush(stdout);
#endif

/****   find sVect   *****/
  vectorSub(upDoms, lowDoms, tot_vars, tempVect2);
  vectorScalarMult(tempVect2, 0.5, tot_vars, tempVect1);
  vectorMult(tempVect1, scaledXVect, tot_vars, tempVect2);
  vectorAdd(upDoms, lowDoms, tot_vars, tempVect1);
  vectorScalarMult(tempVect1, 0.5, tot_vars, tempVect3);  
  vectorAdd(tempVect2, tempVect3, tot_vars, sVect);
#if(MAP_TEST3)
showVector(sVect, 1, tot_vars, "s Vector");
putchar('\n');	fflush(stdout);
#endif

/****   find sLength  ***/
  vectorSub(sVect, r0, tot_vars, sMinus_r0Vect);
  sLength = vectorLength(sMinus_r0Vect, tot_vars);
#if(MAP_TEST4)
showVector(sVect, 1, tot_vars, "sVect");
showVector(r0, 1, tot_vars, "r0");
printf("sLength = %f\n\n", sLength);	fflush(stdout);
#endif
  if(sLength < MAP_RESOLUTION){
    for(i = 1; i <= tot_vars; i++)	Xmapped[i] = r0[i];
    free_vector(tempVect1, 1);
    free_vector(tempVect2, 1);
    free_vector(tempVect3, 1);
    free_vector(sVect, 1);
    free_vector(scaledXVect, 1);
    free_vector(sMinus_r0Vect, 1);
    return;
  }

/***  Get tVect  ****/
/***    Count regions  ****/
  for(i = 1, tCount = 1, infeasible = 0; i < COARSE_RESOLUTION; i++)	{
    vectorScalarMult(sMinus_r0Vect, ((double) i) / ((double) COARSE_RESOLUTION), tot_vars, tempVect1);
    vectorAdd(tempVect1, r0, tot_vars, tempVect2);
    invalid = validate_r0(tempVect2, true_ineqs, tot_vars, tot_ine, &tempVld);
    if(invalid != infeasible)	{
      infeasible = invalid;
      tCount++;
#if(USING_SINGLE_CONVEX_REGION)	
	break; /** for efficiency  ***/
#endif
    }
  }
  oddCount = tCount % 2;
  lastIsInvalid = invalid;
  boundaryIsInvalid = validate_r0(sVect, true_ineqs, tot_vars, tot_ine, &tempVld);
/***  tVect = vector(1, tCount);   ***/
  if(oddCount && !lastIsInvalid)	++tCount;
  if(!oddCount && lastIsInvalid && !boundaryIsInvalid)	tCount += 2;
  tVect = vector(1, tCount);
  
/***   End Count regions  ****/

/***    Populate regions  ****/
/**  NOTE: 	invalid deals with current point;  
		infeasible (not feasible) deals with the region that we "have been" traversing...  ***/  
  tVect[1] = 0.0;
  for(i = 1, tCount = 2, infeasible = 0; i < COARSE_RESOLUTION; i++)	{
    vectorScalarMult(sMinus_r0Vect, ((double) i) / ((double) COARSE_RESOLUTION), tot_vars, tempVect1);
    vectorAdd(tempVect1, r0, tot_vars, tempVect2);
    invalid = validate_r0(tempVect2, true_ineqs, tot_vars, tot_ine, &tempVld);
    if(invalid != infeasible)	{
      tVect[tCount] = fineBoundaryResolution(sMinus_r0Vect, i, tot_vars, r0, true_ineqs, tot_ine, infeasible);  
      tCount++;
      infeasible = invalid;   
#if(USING_SINGLE_CONVEX_REGION)	
	break; /** for efficiency  ***/
#endif   
    }
  }
  if(oddCount && !lastIsInvalid && !boundaryIsInvalid)	
  	tVect[tCount] = 1.0;
  else if(oddCount && !lastIsInvalid && boundaryIsInvalid)
  	tVect[tCount] = fineBoundaryResolution(sMinus_r0Vect, COARSE_RESOLUTION, tot_vars, r0, true_ineqs, tot_ine, infeasible);
  else if(!oddCount && lastIsInvalid && !boundaryIsInvalid)	{
  	tVect[tCount] = fineBoundaryResolution(sMinus_r0Vect, COARSE_RESOLUTION, tot_vars, r0, true_ineqs, tot_ine, infeasible);
  	tCount++;
  	tVect[tCount] = 1.0;
  }
  else	tCount--;
#if(MAP_TEST5)
showVector(tVect, 1, tCount, "tVect");
putchar('\n');	fflush(stdout);
#endif
/***    End Populate regions  ****/

/***   Do mapping!!   ****/
#if(MAP_TEST6)
printf("tCount = %i\n", tCount);  fflush(stdout);
showVector(tVect, 1, tCount, "tVect");
putchar('\n');	fflush(stdout);
#endif
  deltaInvVal = deltaInverse(ymax, tVect, tCount);
#if(MAP_TEST6)
printf("deltaInvVal = %f;      tCount = %i\n", deltaInvVal, tCount);  fflush(stdout);
#endif
  vectorScalarMult(sMinus_r0Vect, deltaInverse(ymax, tVect, tCount), tot_vars, tempVect1);
  vectorAdd(tempVect1, r0, tot_vars, tempVect2);
  for(i = 1; i <= tot_vars; i++)	Xmapped[i] = tempVect2[i];
#if(MAP_TEST6)
showVector(Xmapped, 1, tCount, "Xmapped");
putchar('\n');	fflush(stdout);
#endif

/****   free stuff and return!!   ****/    
/***  for(i = 1; i <= tot_vars; i++)	X[i] = X[i] * MAX_CUBE_VAL;  ****/
  free_vector(tempVect1, 1);
  free_vector(tempVect2, 1);
  free_vector(tempVect3, 1);
  free_vector(sVect, 1);
  free_vector(scaledXVect, 1);
  free_vector(tVect, 1);
  free_vector(sMinus_r0Vect, 1);
  
  return;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   showVector()                             	*/
/*                                                                              */
/*           SYNOPSIS          :   void showVector(vect, start,			*/
/*           						stop, char* name)	*/
/*                                                                              */
/*           DESCRIPTION       :   Screen dump a vector			        */
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

void showVector(vect, start, stop, name)
VECTOR vect;
int start, stop;
char* name;
{
  int i;
  printf("\n%s:  ", name);	fflush(stdout);
  for(i = start; i <= stop; i++)	{
  	printf("%f ", vect[i]);	fflush(stdout);
  }
  putchar('\n');
  fflush(stdout);
  return;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   vectorScalarMult()				*/
/*                                                                              */
/*           SYNOPSIS          :   void vectorScalarMult(vect, scalar, 		*/
/*					size, result)				*/
/*                                                                              */
/*           DESCRIPTION       :   Perform scalar multiplication 		*/
/*					result = vect * scalar			*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

void vectorScalarMult(vect, scalar, size, result)
VECTOR vect, result;
int size;
double scalar;
{
  int i;  
  for(i = 1; i <= size; i++)	result[i] = vect[i] * scalar;  
  return;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   vectorAdd()					*/
/*                                                                              */
/*           SYNOPSIS          :   void vectorAdd(vect1, vect2, 		*/
/*					size, result)				*/
/*                                                                              */
/*           DESCRIPTION       :   Perform vector addition	 		*/
/*					result = vect1 + vect2			*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

void vectorAdd(vect1, vect2, size, result)
VECTOR vect1, vect2, result;
int size;
{
  int i;  
  for(i = 1; i <= size; i++)	result[i] = vect1[i] + vect2[i];  
  return;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   vectorSub()					*/
/*                                                                              */
/*           SYNOPSIS          :   void vectorSub(vect1, vect2, 		*/
/*					size, result)				*/
/*                                                                              */
/*           DESCRIPTION       :   Perform vector subtraction	 		*/
/*					result = vect1 - vect2			*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

void vectorSub(vect1, vect2, size, result)
VECTOR vect1, vect2, result;
int size;
{
  int i;  
  for(i = 1; i <= size; i++)	result[i] = vect1[i] - vect2[i];  
  return;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   vectorMult()					*/
/*                                                                              */
/*           SYNOPSIS          :   void vectorAdd(vect1, vect2, 		*/
/*					size, result)				*/
/*                                                                              */
/*           DESCRIPTION       :   Perform vector vector multiplication	 	*/
/*					this is NOT inner product!!		*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

void vectorMult(vect1, vect2, size, result)
VECTOR vect1, vect2, result;
int size;
{
  int i;  
  for(i = 1; i <= size; i++)	result[i] = vect1[i] * vect2[i];  
  return;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   vectorLength()				*/
/*                                                                              */
/*           SYNOPSIS          :   double vectorAdd(vect, size)			*/
/*                                                                              */
/*           DESCRIPTION       :   Find 2-norm of a vector			*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

double vectorLength(vect, size)
VECTOR vect;
int size;
{
  int i; 
  double total; 
  for(i = 1, total = 0.0; i <= size; i++)	total += vect[i] * vect[i];  
  return	sqrt(total);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   sum_tSegments()				*/
/*                                                                              */
/*           SYNOPSIS          :   double sum_tSegments(tVect, qtySegs)		*/
/*                                                                              */
/*           DESCRIPTION       :   Sum length of given (subset of) t segments	*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

double sum_tSegments(tVect, qtySegs)
VECTOR tVect;
int qtySegs;
{
  int i;
  double total;  
  for(i = 1, total = 0.0; i <= qtySegs; i++)	{
    total += tVect[2*i] - tVect[2*i - 1];
  }  
  return	total;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   delta()					*/
/*                                                                              */
/*           SYNOPSIS          :   double delta(t, tVect, tCount)		*/
/*                                                                              */
/*           DESCRIPTION       :   Map from feasible space to unit hypercube	*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

double delta(t, tVect, tCount)
VECTOR tVect;
int tCount;
double t;  /** t is assumed to be "feasible"  **/
{
  double d;
  int subscript;  
  
  d = sum_tSegments(tVect, tCount / 2);
  if(d == 0.0)	return 0.0;
  
/***  find min subscript  ***/
  subscript = 1;
  while(1)	{
    if( (subscript * 2) >= tCount )	break;
    if( tVect[2*subscript] >= t )	break;	
    subscript++;
  }  
  
  return	( (t - tVect[2*subscript - 1]) + sum_tSegments(tVect, subscript - 1) ) / d;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   deltaInverse()				*/
/*                                                                              */
/*           SYNOPSIS          :   double deltaInverse(a, tVect, tCount)	*/
/*                                                                              */
/*           DESCRIPTION       :   Map from unit hypercube to feasible space 	*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

double deltaInverse(a, tVect, tCount)
VECTOR tVect;
int tCount;
double a;
{
  double d, denom, numer, dj, tLow, tHi, delta_tLow, delta_tHi;
  int subscript;  

  d = sum_tSegments(tVect, tCount / 2);
  if(d == 0.0)	return 0.0;
  
/***  find min subscript  ***/
  subscript = 1;
  while(1)	{
    if( (subscript * 2) >= tCount )	break;
    if( delta( tVect[2*subscript], tVect, tCount ) >= a )	break;	
    subscript++;
  } 
  
  tHi = tVect[2*subscript];
  tLow = tVect[2*subscript - 1];
  delta_tHi = delta(tHi, tVect, tCount);
  delta_tLow = delta(tLow, tVect, tCount);
  
  denom = delta_tHi - delta_tLow; 
  if(denom <= 0.0)	return tHi;
  numer = a - delta_tLow;
  if(numer <= 0.0)	return tLow;
  if(a >= delta_tHi)	return tHi;
  
  dj = tHi - tLow;
  return	tLow + ( dj * (a - delta_tLow) / denom );
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   fineBoundaryResolution()			*/
/*                                                                              */
/*           SYNOPSIS          :   double fineBoundaryResolution(sMinus_r0Vect,	*/
/*					incr, tot_vars, r0, true_ineqs, 	*/
/*					tot_ine, infeasible)			*/
/*                                                                              */
/*           DESCRIPTION       :   Find boundary to fine precision using binary	*/
/*						search.				*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

double fineBoundaryResolution(sMinus_r0Vect, incr, tot_vars, r0, true_ineqs, tot_ine, infeasible)
VECTOR sMinus_r0Vect, r0;
MATRIX true_ineqs;
int incr, tot_vars, tot_ine, infeasible;
{
  VECTOR tempV1, tempV2;
  int i, invalid, tempVld;
  double upper, lower, middle;
  
  tempV1 = vector(1, tot_vars);
  tempV2 = vector(1, tot_vars);
  upper = (double) incr;
  lower = ((double) incr) - 1.0;
  
  for(i = 1; i <= FINE_RESOLUTION; i++)	{
    middle = (upper + lower) / 2.0;
    if( ((upper - middle) < MAP_RESOLUTION) || ((middle - lower) < MAP_RESOLUTION) )	break;
    vectorScalarMult(sMinus_r0Vect, ((double) middle) / ((double) COARSE_RESOLUTION), tot_vars, tempV1);
    vectorAdd(tempV1, r0, tot_vars, tempV2);
    invalid = validate_r0(tempV2, true_ineqs, tot_vars, tot_ine, &tempVld);    
    if(invalid != infeasible)	upper = middle;
    else			lower = middle;
  }  
  
  free_vector(tempV1, 1);
  free_vector(tempV2, 1);
  return	infeasible ? upper / COARSE_RESOLUTION : lower / COARSE_RESOLUTION;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   read_file_UHC()                              */
/*                                                                              */
/*           SYNOPSIS          :   void read_file_UHC(equalities,inequalities,	*/
/*					domains,true_equalities,		*/
/*					true_inequalities,true_domains,tot_arr);*/
/*                                                                              */
/*           DESCRIPTION       :   This function reads from an input file the   */
/*                                  data and writes on the the corresponding    */
/*                                  equalities, inequalites and domain matrices */
/* 				    for both unit hypercube (UHC) and true vals.*/
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   main()                                       */
/*                                                                              */
/*           AUTHOR            :   David Hill		                        */
/*                                                                              */
/*           DATE              :   1/20/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void read_file_UHC(domains,true_equalities,true_inequalities,true_domains,tot_arr)
MATRIX domains,true_equalities,true_inequalities,true_domains;
IVECTOR tot_arr;
{
  int t2,i,j,total_variables;
  float t1,t3;

  if(tot_arr[1] != 0)
    for(i=1; i<=tot_arr[1]; i++)
      for(j=1; j<=tot_arr[0] + 1; j++)
        fscanf(input," %f",&true_equalities[i][j]);

/********************
  if(tot_arr[2] != 0)
    for(i=1; i<=tot_arr[2]; i++)
      for(j=1; j<=tot_arr[0]+1; j++) {
        fscanf(input," %f",&true_inequalities[i][j]);
      }
********************/      

  for(i=1; i<=tot_arr[0]; i++)
    {
      true_domains[i][1] = MIN;
      true_domains[i][2] = (float) i;
      true_domains[i][3] = MAX;
    }

  if(tot_arr[3] != 0)
    for(i=1; i<=tot_arr[3]; i++)
      {
        fscanf(input," %f %d %f",&t1,&t2,&t3);
        true_domains[t2][1] = t1;
        true_domains[t2][3] = t3;
      }      

  for(i=1; i<=tot_arr[0]; i++)
    {
      domains[i][1] = MIN_CUBE_VAL;
      domains[i][2] = (float) i;
      domains[i][3] = MAX_CUBE_VAL;
    }
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   initialize_r0()                              */
/*                                                                              */
/*           SYNOPSIS          :   int initialize_r0(r0,ineqs,doms,		*/
/*						tot_vars, tot_ine)		*/
/*                                                                              */
/*           DESCRIPTION       :   This function generates random values for    */
/*                                  each of the system variables, such that	*/
/*                                  none of the constriants are violated; if no */
/*                                  such values could be found after a          */
/*                                  predetermined number of times, it returns   */
/*                                  FALSE.                                      */
/*                                                                              */
/*           FUNCTIONS CALLED  :   frange_ran(),                                */
/*                                 ivector(),                                   */
/*                                 matrix(),                                    */
/*                                 vector().                                    */
/*                                                                              */
/*           CALLING FUNCTIONS :   main()                                       */
/*                                                                              */
/*           AUTHOR            :   David Hill					*/
/*                                                                              */
/*           DATE              :   2/5/98	                                */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

int initialize_r0(r0,ineqs,doms,tot_vars, tot_ine)
VECTOR r0;
MATRIX ineqs,doms;
int tot_vars, tot_ine;
{
  long count;
  int i, j, k, tempVld;
  time_t tp;
  
  time(&tp);
  srand( (unsigned) tp );

/***********************  for k * 100,000 attempts:  ****/  
  for(k = 0; k < 100; k++)	{
    /*    printf("Attempting reference point initializations %li - %li\n", k * 10 * TRIES, (k+1) * 10 * TRIES); */
    if(!(k % 20))	{   /***   reseed random generator!!   ***/
    	time(&tp);
	srand( (unsigned) tp );
    }
    for(count = 0; count < 10 * TRIES; count++)	{
      /****	for(i = 1; i <= tot_vars; i++)	r0[i] = frange_ran(doms[i][1], doms[i][3]);	***/
      for (i = 1; i <= tot_vars; i++)
   	r0[i] = (double)rand()/RAND_MAX;
      for (i = 1; i <= tot_vars; i++)	{
      	r0[i] = r0[i]*(doms[i][3] - doms[i][1]) + doms[i][1];
      }
      if( !validate_r0(r0, ineqs, tot_vars, tot_ine, &tempVld) )		{
        printf("Valid reference point found!!\n");
        printf("Starting Genocop...\n\n");
        return 0;
      }
    }
  }

  for(j = 1; j <= 3; j++)	{

    printf("Cannot find valid reference point.  Enter by hand.\n");
    for(i = 1; i <= tot_vars; i++)	r0[i] = handScan_r0(i);
    printf("r0: ");
    for(i = 1; i <= tot_vars; i++)	printf("%f ", r0[i]);
    putchar('\n');

    if( !validate_r0(r0, ineqs, tot_vars, tot_ine, &tempVld) )	{
    	printf("Default reference point used...\n");
    	return 0;
    }
  }
  
  return 1;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   handScan_r0()				*/
/*                                                                              */
/*           SYNOPSIS          :   void handScan_r0(cnt)			*/
/*                                                                              */
/*           DESCRIPTION       :   User enters reference point by hand		*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/

double handScan_r0(cnt)
int cnt;
{
  char c;
  int i = 0;
  char buf[256];
  
  printf("Enter coordinate %i\n", cnt);
  while( (c = getchar()) != '\n')	buf[i++] = c;
  buf[i] = 0;
  
  return	atof(buf);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   validate_r0()                              	*/
/*                                                                              */
/*           SYNOPSIS          :   int initialize_r0(r0,ineqs,			*/
/*						tot_vars, tot_ine)		*/
/*                                                                              */
/*           DESCRIPTION       :   This function validates r0 per vector 	*/
/*							of inequalities         */
/*                                                                              */
/*           FUNCTIONS CALLED  :                             			*/
/*                                                                              */
/*           CALLING FUNCTIONS :   initialize_r0()                              */
/*                                                                              */
/*           AUTHOR            :   David Hill					*/
/*                                                                              */
/*           DATE              :   2/12/98	                                */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

int validate_r0(X,ineqs,tot_vars, tot_ine, vldRtn)
VECTOR X;
MATRIX ineqs;
int tot_vars, tot_ine;
int* vldRtn;
{
  VECTOR nlineq;
  int rVal, i;
  
  *vldRtn = 0;
  rVal = 0;  
  nlineq = vector(1, tot_ine);
  
  switch(test_num)
  {
#include  "nlineq.c"  
	default:
	  break;
  }
  
  for(i = 1; i <= tot_ine; i++)
  	if( nlineq[i] > 0.0 )	{
  		rVal = 1;
  		*vldRtn = i;
  		break;
  	}
  	
  free_vector(nlineq, 1);
  return rVal;
}

/**********************************
int validate_r0(r0,ineqs,tot_vars, tot_ine, vldRtn)
VECTOR r0;
MATRIX ineqs;
int tot_vars, tot_ine;
int* vldRtn;
{
  int i, j;
  double val;
  
  for(i = 1; i <= tot_ine; i++)	{
    val = 0.0;
    for(j = 1; j <= tot_vars; j++)	val += ineqs[i][j] * r0[j];  
    if( val > ineqs[i][tot_vars + 1] )	{ *vldRtn = i; return 1; }
  }
  
  vldRtn = 0;
  return 0;
}
**********************************/


/****   Template!!!!!!!    *********/


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   xxxxx()*/
/*                                                                              */
/*           SYNOPSIS          :   void xxxxx(x, x)*/
/*                                                                              */
/*           DESCRIPTION       :   xxxxx*/
/*                                                                              */
/*           FUNCTIONS CALLED  :                                                */
/*                                                                              */
/*           CALLING FUNCITONS :   			                        */
/*                                                                              */
/*           AUTHOR            :   David Hill                                   */
/*                                                                              */
/*           DATE              :   2/12/98                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/********************************************************************************/
/*************************
void xxxxx(x, x)
VECTOR x;
int x;
{
  return;
}
**********************/
