#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<string.h>

#define TRUE 1
#define FALSE 0

#define DOS_SYS  FALSE           /* set to true for dos, false for unix */
#define UNIX_SYS TRUE            /* set to true for unix, false for dos */

#define flip()  ((int) ((newrand()*(long)2)/(long) 65535))
#define MIN -32768
#define MAX 32768
#define BIGINT 100000000
#define HEAD 1
#define TAIL 0
#define TRIES 10000
#define MAX_VAR 60
#define MULT 25173
#define INCR 13849
#define MOD ((long int) 65536)
#define SHUFFLE 256   /* size of random number shuffle array */
#define EST_OFFSET 0  /* offset in hours from Eastern Standard Time zone)  */

/***  Dave Adds:   ***/
#define MAX_CUBE_VAL		(1)   /***  maximum hypercube value ***/
#define MIN_CUBE_VAL		((-1) * (MAX_CUBE_VAL))  /***  minimum hypercube value ***/
#define COARSE_RESOLUTION		(15)	/* feasible space searching  **/
#define FINE_RESOLUTION			(8)	/* feasible space searching  **/
#define USING_SINGLE_CONVEX_REGION	(0)    /*  leave as 0  */
#define MAP_TEST			(0)   /*  for testing  **/
#define MAP_RESOLUTION			(0.00005)
#define VLD_TEST			(0)
/***  End Dave Adds   ***/

typedef float **MATRIX;
typedef float *VECTOR;
typedef int **IMATRIX;
typedef int *IVECTOR;
typedef int FLAG;
typedef int TOSS;
typedef struct {int r; int c;}INDEX;

#if UNIX_SYS
  FILE *input,*output;
  int   test_num;
  long rseed;
  unsigned int rand_array[SHUFFLE];
#endif

float **matrix();
float *vector();

float det();
float evaluate();
float frange_ran();
float get_F();
float x_pow_y();

FLAG oper1();
FLAG oper2();
FLAG oper3();
void oper4();
void oper5();
FLAG oper6();

int **imatrix();
int *ivector();

unsigned long factorial();
int find_sum();
int irange_ran();
int p_equalities();
int x_power_y();

FLAG initialize_x2();
FLAG satis_con();

void assign_probab();
void bi_deci();
void change_coeff();
void copy_matrix();

void find_X();
void find_ac1_ac2();
void find_cum_probab();
void find_final_mat1();
void find_final_mat2();
void find_final_mat3();
void find_limits();
void find_lu1_lu2();
void find_new_in_eq();
void find_org_in_eq();
void find_probability();
void find_range();
void find_x1_x2();

void free_vector();
void free_ivector();
void free_matrix();
void free_imatrix();

void get_var_order();
void inverse();
void initialize();
void main();
void mmprod();
void mvprod();
void nrerror();

void optimization();
void print_domains();
void print_equalities();
void print_inequalities();
void print_ivector();
void print_matrix();
void print_population();
void print_vector();

FLAG feasible();



void read_file();
void seed();
void sort();
void swap();
void write_file();
void find_live();
int  find_die();
unsigned int newrand();
unsigned int randint();

/***   Dave adds  ***/
void doHomomorphMap();
void read_file_UHC();
int initialize_r0();
double handScan_r0();
int validate_r0();
void showVector();
void vectorScalarMult();
void vectorAdd();
void vectorMult();
void vectorSub();
double vectorLength();
double sum_tSegments();
double delta();
double deltaInverse();
double fineBoundaryResolution();
/***   End Dave adds  ***/



