
#include <stdio.h>
#include <math.h>

main()
{
double X[21];
int feas, i,j,k;
double sum, con1, con2, con3, con4, con5, con6, con7, con8, con9, fin;
double g[20];
double h[20];
double epsilon13;


epsilon13 = 0.000001;

feas = 0;

for( j=1; j<=1000000; ++j)
  {
for (i=1; i<=8; ++i)
   X[i] = (double)rand()/32767.0;

X[1] = X[1]*9900.0 + 100.0;
X[2] = X[2]*9000.0 + 1000.0;
X[3] = X[3]*9000.0 + 1000.0;
X[4] = X[4]*990.0 + 10.0;
X[5] = X[5]*990.0 + 10.0;
X[6] = X[6]*990.0 + 10.0;
X[7] = X[7]*990.0 + 10.0;
X[8] = X[8]*990.0 + 10.0;

g[1] =  1.0 - 0.0025*(X[4] + X[6]);
g[2] =  1.0 - 0.0025*(X[5] + X[7] - X[4]);
g[3] = 1.0 - 0.01*(X[8] - X[5]);
g[4] = X[1]*X[6] - 833.33252*X[4] - 100*X[1] + 83333.333;
g[5] = X[2]*X[7] - 1250.0*X[5] - X[2]*X[4] + 1250.0*X[4];
g[6] = X[3]*X[8] - 1250000.0 - X[3]*X[5] + 2500.0*X[5];

if ((g[1] >= 0.0) && (g[2] >= 0.0) && (g[3] >= 0.0) && (g[4] >= 0.0)
    && (g[5] >= 0.0) && (g[6] >= 0.0))
		{
		++feas;
if (feas == 1)
  { 
    printf("TEST CASE #2\n\n");
    for (k = 1; k <= 8; ++k)
      printf("X[%d] = %f\n", k, X[k]);
   }	}
  }

printf("\n Total feasible points for case #2 = %d\n\n", feas);


 
}


