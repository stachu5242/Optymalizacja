#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv)
{
  FILE* fin = fopen("cons.in", "r");
  FILE* fout = fopen("cons.out", "w");
  FILE* fin2 = fopen("mapTest.out", "r");
  char c;
  int i, j, k;
  char buf[256];
  char fileName[256];
  long gen, time, totGen, totTime;
  double val, totVal;
  int runsPerFile;
  
  if(argc != 3)	{
    printf("\nUsage - consTest totalFiles runsPerFile\nProgram exits!!\n\n");
    return 1;
  }
  runsPerFile = atoi(argv[2]);
  
  for(k = 0; k < atoi(argv[1]); k++)	{
    i = 0;
    while( (c = getc(fin)) != 0x0a)	{
      fileName[i] = c;
      i++;
    }
    fileName[i] = 0;
    strtok(fileName, " \t");
    
    totTime = 0;  totVal = 0.0; totGen = 0;
    for(j = 0; j < runsPerFile; j++)	{
      i = 0;
      while( (c = getc(fin2)) != ' ')	{
        buf[i] = c;
        i++;
      }
      buf[i] = 0;
      gen = atol(buf);
      totGen += gen;
      
      i = 0;
      while( (c = getc(fin2)) != 0x0a)	{
        buf[i] = c;
        i++;
      }
      buf[i] = 0;
      val = atof(buf);
      totVal += val;
      
      i = 0;
      while( (c = getc(fin2)) != 0x0a)	{
        buf[i] = c;
        i++;
      }
      buf[i] = 0;
      time = atol(buf);
      totTime += time;
    }
    fprintf(fout, "Averages for %i runs of %s\n", runsPerFile, fileName);
    fprintf(fout, "Generations: %.2f\nValue: %.8f\nTime: %.2f\n\n", 
    		(double) totGen / runsPerFile, totVal / runsPerFile, (double) totTime / runsPerFile);
    fflush(fout);    	
  }
  
  fclose(fin);  fclose(fin2);  fclose(fout);
  return 0;
}













