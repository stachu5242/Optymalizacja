#define TEST 0
#include "genet.h"

replace_population()
{

	int p,q,i,j,z,v,w, cross_no,m1,m2,found, no_of_dif_par;
	int mut_vec[POP], inv_vec[POP], cro_vec[POP];
	
	i=0;
	for (j=0; j<pop; ++j)
	   if (parents[j] != 0) i++;
	no_of_dif_par = i;
	
	for (j=0; j<pop; ++j)
	{
	   mut_vec[j] = 0;
	   inv_vec[j] = 0;
	   cro_vec[j] = 0;
	 }
	 
	 
    z = mutat;
   
    while (z > 0)
    {
    v = random0(no_of_dif_par);
    for (p=0; p<pop; ++p)
       {
       if (parents[p] != 0)
          {
          if (v == 0) {mut_vec[p]++; parents[p]--;}
           v = v - 1;
          }
        }
     z = z-1;
     i=0;
	 for (j=0; j<pop; ++j)
	    if (parents[j] != 0) i++;
	 no_of_dif_par = i;
     }
     
    z = inver;
   
    while (z > 0)
    {
    v = random0(no_of_dif_par);
    for (p=0; p<pop; ++p)
       {
       if (parents[p] != 0)
          {
          if (v == 0) {inv_vec[p]++; parents[p]--;}
           v = v - 1;
          }
        }
     z = z-1;
     i=0;
	 for (j=0; j<pop; ++j)
	    if (parents[j] != 0) i++;
	 no_of_dif_par = i;
     }
     
    z = cross;
   
    while (z > 0)
    {
    v = random0(no_of_dif_par);
    for (p=0; p<pop; ++p)
       {
       if (parents[p] != 0)
          {
          if (v == 0) {cro_vec[p]++; parents[p]--;}
           v = v - 1;
          }
        }
     z = z-1;
     i=0;
	 for (j=0; j<pop; ++j)
	    if (parents[j] != 0) i++;
	 no_of_dif_par = i;
     }
        
/*	
	printf("\nmutation\n");
	for (i=0; i<pop; ++i)
	   printf("%d ", mut_vec[i]);
	printf("\n");
	printf("\ninversion\n");
	for (i=0; i<pop; ++i)
	   printf("%d ", inv_vec[i]);
	printf("\n");
	printf("\ncrossover\n");
	for (i=0; i<pop; ++i)
	   printf("%d ", cro_vec[i]);
	printf("\n");
*/	
	
	
	
	
	for (p=0; p<pop; ++p)
	{
	   while (mut_vec[p] != 0)
	   {
			for (i=0; i<k; ++i)
			for (j=0; j<n; ++j)
				par[i][j] = pp[p]->sol[i][j];
		
		   mutate();
			


			q=0;
			while (dead[q] == 0 && q < pop) ++q;
			if ( q >= pop  )
				{ printf ("replace_population error: no dead left\n"); return(2);}

			dead[q] = 0;
			for (i=0; i<k; ++i)
			for (j=0; j<n; ++j)
				pp[q]->sol[i][j] = chd[i][j];
				
	        
	        mut_vec[p]--;
	  
		}
		 
		 
	while (inv_vec[p] != 0)
	   {
			for (i=0; i<k; ++i)
			for (j=0; j<n; ++j)
				par[i][j] = pp[p]->sol[i][j];
				
	       
	           
		   inverse();
			


			q=0;
			while (dead[q] == 0 && q < pop) ++q;
			if ( q >= pop  )
				{ printf ("replace_population error: no dead left\n"); return(2);}

			dead[q] = 0;
			for (i=0; i<k; ++i)
			for (j=0; j<n; ++j)
				pp[q]->sol[i][j] = chd[i][j];
		
	        inv_vec[p]--;
	  
		}
      }
     
      cross_no = 0;
      z = cross;
      
      while (z > 0)
      {
         for (p = 0; p < pop; ++p)
         {
            if (cro_vec[p] != 0)
		    {  cro_vec[p] = cro_vec[p] -1; 
	           z = z -1;
		       cross_no = cross_no + 1;
		       
		       if ((cross_no % 2) == 0)
		       {
			   for (i=0; i<k; ++i)
			   for (j=0; j<n; ++j)
				  par_b[i][j] = pp[p]->sol[i][j];
			
	           crossover();
	       
	           q=0;
			   while (dead[q] == 0 && q < pop) ++q;
			   if ( q >= pop  )
				{ printf ("replace_population error: no dead left\n"); return(2);}

			   dead[q] = 0;
			   for (i=0; i<k; ++i)
			   for (j=0; j<n; ++j)
				  pp[q]->sol[i][j] = chd_a[i][j];
			
	           
	           q=0;
			   while (dead[q] == 0 && q < pop) ++q;
			   if ( q >= pop  )
				  { printf ("replace_population error: no dead left\n"); return(2);}

			   dead[q] = 0;
			   for (i=0; i<k; ++i)
			   for (j=0; j<n; ++j)
				  pp[q]->sol[i][j] = chd_b[i][j];
			
	           } 
	     
	        else
	      
	           { 
	           
	           for (i=0; i<k; ++i)
			   for (j=0; j<n; ++j)
				  par_a[i][j] = pp[p]->sol[i][j];
				
	          
	           } 
	      
	        
		 }
	  }
	 
   }		
}
