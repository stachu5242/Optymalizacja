#include "genet.h"

print_results()

{
int i,j;

   printf("\nfinal evaluation %9ld\n\n", pp[0]->eval);
   printf("best population:\n");
   for (i = 0; i<k; ++i) {printf("\n");
   for (j = 0; j<n; ++j)
      printf("%4d", pp[0]->sol[i][j]);
      } 
   printf("\n\n\n");
}