#include "genet.h"

assign_probabilities1()
{

	int p;
	
	prob[0] = 1 - sprob;
	
	for (p=1; p < pop; ++p)
	   prob[p] = prob[p-1]*sprob;
	            
	for (p = 1; p < pop; ++p)
	   prob[p] = prob[p] + prob[p-1];
  
	for (p = 0; p < pop; ++p)
	   prob[p] = prob[p]/prob[pop-1];	/* added, GAV to make sure that we have 1.00 at the end */
}
