#define TEST 0
#include "genet.h"

inverse()

{
int i, j;


for (i=0; i<k; ++i)
for (j=0; j<n; ++j)
	chd[i][j] = par[i][j];
			
}