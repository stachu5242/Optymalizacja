#include "genet.h"

evaluate_population()
{
int p,i,j,q;
Cost sum;

for (p=0;p<pop;++p){
   sum=0;
   for (i=0; i<k; ++i)
       for (j=0;j<n;++j)
           sum = sum + cost[i][j]*(Cost)(pp[p]->sol[i][j]);
                            
   pp[p]->eval = sum;}
}

print_values()
{
	int p;
	
	for ( p=0; p < pop; p++) printf("%d:  %ld\n",p,pp[p]->eval);
}
