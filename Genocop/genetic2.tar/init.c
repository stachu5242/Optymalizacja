#define TEST 0
#include "genet.h"


init_one_population( sour_size, dest_size, sour_tab, dest_tab)
int sour_size, dest_size;
int sour_tab[];
int dest_tab[];
{
	int p, i, j, temp_i, temp_j, res_i, res_j, val;
	int taken_row[K];
	int taken_col[N];
	int count;
	int row = 0;
	int col = 0;
	
	for (i=0; i < sour_size; ++i){
	   for (j=0; j < dest_size; ++j) {initial[i][j] = 0;}}
	
	for (i = 0; i < sour_size; ++i) {taken_row[i] = 0;}
	for (j = 0; j < dest_size; ++j) {taken_col[j] = 0;}
	
	for (i = 0; i < sour_size; ++i)
	   if (sour_tab[i] != 0) row = row +1; else taken_row[i] = 1;
	
	for (i = 0; i < dest_size; ++i)
	   if (dest_tab[i] != 0) col = col +1; else taken_col[i] = 1;
	   
	
	
	while ((row != 0) || (col != 0)){
	   temp_i = random0(row);
	   temp_j = random0(col);
	
	   p = -1; count = -1;
		while (count < temp_i)
		{
			++p;
			if (taken_row[p] == 0) count++;
		}
	   res_i = p;
	
	   p = -1; count = -1;
	   while (count < temp_j){++p;
	      if (taken_col[p] == 0) count++;
	      }
	   res_j = p;   
	
	   val = min(sour_tab[res_i], dest_tab[res_j]);
	   initial[res_i][res_j] = val;
	   sour_tab[res_i] = sour_tab[res_i] - val;
	   dest_tab[res_j] = dest_tab[res_j] - val;
	   if (sour_tab[res_i] == 0) {taken_row[res_i] = 1; row = row - 1;}
	   if (dest_tab[res_j] == 0) {taken_col[res_j] = 1; col = col - 1;}
	   
	   }
#if TEST
	   for (i=0; i < k; ++i)                                       
	     {  printf("%d: ",i);
	     	for (j=0; j < n; ++j)                                     
	      		printf("  %d",initial[i][j]);
	      	printf("\n");
	      }
	    printf("\n");   
#endif
}

min (x,y)
int x,y;
{
	if (x < y) return (x); else return (y);
}

max (x,y)
int x,y;
{
	if (x < y) return (y); else return (x);
}


random0(p)
int p;
{
	int r;
	
	if (p ==0) return (0); else {r = rand()%p; return(r);}
}

random1(p)
int p;
{
int r;

	if (p ==0) return (0); else {r = rand()%p; return(r+1);}
}

