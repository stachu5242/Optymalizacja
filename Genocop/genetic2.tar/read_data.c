#include "genet.h"
/*
#include <strings.h>
*/
int read_data()
/* 
   Version 4
   modified 15 Jan 89 GAV
   to read in self-describing data. Returns EOF if it strikes
   an EOF, 0 if a blank line and some other value if an error
*/

{
	int i = -1;
	int j = -1;
	int sum_dest = 0;
	int sum_sour = 0;
	char line[100],fld1[50],fld2[50];
	int sn;		/* result of scanf */
	int errs = EOF;	/* return result   */
	int run;

  	while ( gets(line) !=  NULL )
	{
		if (strcmp(line,"")==0) {
			/* printf("null line\n");*/ errs = 0; 
			break;
		}
		puts(line);

		sscanf(line,"%s %s",fld1,fld2);
		/*  printf("|%10s|%10s|\n",fld1,fld2);  */

		if (strncmp(fld1,"#",1)==0){
		}
		else if (strcmp(fld1,"")==0){
			errs = 0;
			break;
		}	/* line of spaces or tabs only */
		else if (strncmp(fld1,"title",5)==0){
		}
		else if (strncmp(fld1,"pop",3)==0){
			sscanf(fld2,"%d",&pop);
			if (pop==0) return(1);
			if (pop > 50)
			{
				printf(" pop must be <=50\n");
				return(1);
			}
		}
		else if ( strncmp(fld1,"sprob",5)==0){
			sscanf(fld2,"%lf",&sprob);
			if ( sprob <= 0 ) {
				printf("sprob must be > 0\n");
				errs=1; 
				break;
			}
		}
		else if ( strncmp(fld1,"seed",4)==0 ){
			sscanf(fld2,"%d",&seed0);
			srand(seed0);
		}
		else if ( strncmp(fld1,"cross",5)==0 ){
			sscanf(fld2,"%d",&cross);
			if (cross % 2)  {
				printf(" cross must be even\n");
				errs=1;
				break; 
			}
		}
		else if (strncmp(fld1,"mutat",5)==0)sscanf(fld2,"%d", &mutat);
		else if (strncmp(fld1,"run",3)==0)sscanf(fld2,"%d", &run);
		else if ( strncmp(fld1,"inver",5)==0)sscanf(fld2,"%d", &inver);
		else if ( strncmp(fld1,"it",2)==0 ) sscanf(fld2,"%d",&it);
		else if ( strncmp(fld1,"nsource",7)==0 ){
			sscanf(fld2,"%d",&k);
			if ( k > 10) {
				printf(" nsource must be <= 10\n");
				errs=1; 
				break;
			}
		}
		else if ( strncmp(fld1,"ndest",5)==0 ){
			sscanf(fld2,"%d",&n);
			if ( n > 10) {
				printf(" ndest must be <= 10\n");
				errs=1; 
				break;
			}
		}
		else if ( strncmp(fld1,"sources",7)==0 ){
			if ( k == 0 ) {
				printf("nsources is zero\n"); 
				errs=1;
				break;
			}
			for (i=0 ;i < k; i++) {
				sn = scanf("%d", &sour[i]);
				printf("%5d ",sour[i]); 
			}
			printf("\n");
			gets(line);
		}
		else if ( strncmp(fld1,"dests",5)==0 )	{
			if ( n == 0 ) {
				printf("ndest is zero\n");
				errs=1; 
				break;
			}
			for ( j = 0; j < n; j++) {
				sn=scanf("%d", &dest[j]);
				printf("%5d ",dest[j]); 
			}
			printf("\n");
			gets(line);
		}
		else if ( strncmp(fld1,"costs",5)==0 )	{
			if ( k == 0 || n == 0) {
				printf("nsources or ndest is zero\n");
				errs=1; 
				break;
			}
			for ( i = 0; i < k; i++) {
				for ( j = 0; j < n; j++) {
					scanf("%d", &cost[i][j]);
					printf("%5d ",cost[i][j]); 
				}
				printf("\n");
			}
			gets(line);
		}
		else if ( strncmp(fld1,"optimum",7)==0){
		  sscanf(fld2,"%ld", &optimum);}
		else if ( strncmp(fld1,"end",3)==0){ errs = -1;break;}
		else
		{ 
			printf("I cannot understand this data\n"); 
			errs=1; 
			break;
		}
	}


	/* check sources and destination sums */
	if (!errs) {
		for (i=0; i < n; ++i) sum_dest = sum_dest + dest[i];
		for (i=0; i < k; ++i) sum_sour = sum_sour + sour[i];
		if (sum_dest != sum_sour) {
			printf("Sums of sources and dests do not agree\n");
			errs=2;
		}
	}
	return(errs);
}
