#define TEST 0
#include "genet.h"

crossover()

{
	int i, j, found, found_row, found_col, sum;
        int finish, got, start_i, start_j;
	int rem[K][N], org[K][N], visited[K][N];
	
#if TEST
	
	for (i=0; i<k; ++i)
	for (j=0; j<n; ++j)
		{chd_a[i][j] = par_a[i][j];
		 chd_b[i][j] = par_b[i][j];
		}
	
#endif	
		
	sum = 0;
	
	for (i=0; i<k; ++i)
	for (j=0; j<n; ++j)
	{
	   chd_a[i][j] = (par_a[i][j] + par_b[i][j])/2;
	   chd_b[i][j] = (par_a[i][j] + par_b[i][j])/2;	
	   rem[i][j] = (par_a[i][j] + par_b[i][j])%2;
	   org[i][j] = rem[i][j];
	   sum = sum + rem[i][j];
	   visited[i][j] = 0;
	}
	
	while (sum > 0)
	{
	   found = 0;
	   for (i=0; i<k; ++i)
	   for (j=0; j<n; ++j)
		  if ((rem[i][j] == 1) && (found == 0) && (visited[i][j] == 0))
		  {found_row = i; found_col = j; found = 1;}
		  
	   start_i = found_row;
	   start_j = found_col;
	   visited[start_i][start_j] = 1;
	   finish = 0;
	   sum = sum - 1;
	   while (finish == 0)
	   {
	      got = 0;
	      i = 0;
	      while ((i<k) && (got == 0))
	      {
	         if ((rem[i][found_col] == 1) && (visited[i][found_col] == 0))
	         {
	            got = 1;
	            sum = sum - 1;
	            found_row = i;
	            visited[found_row][found_col] = 1;
	            rem[found_row][found_col] = 0;
	         }
	         i = i + 1;
	      }
	      got = 0;
	      j = 0;
	      while ((j<n) && (got == 0))
	      {
	         if ((rem[found_row][j] == 1) && (visited[found_row][j] == 0))
	         {
	            got = 1;
	            sum = sum - 1;
	            found_col = j;
	            visited[found_row][found_col] = 1;
	         }
	         if ((rem[found_row][j] == 1) && (found_row == start_i) && (j == start_j))
	         {
	            finish = 1;
	            got = 1;
	         }
	         j = j + 1;
	      }
	   } 
	}
	
	for (i=0; i<k; ++i)
	for (j=0; j<n; ++j)
	{
	   chd_a[i][j] = chd_a[i][j] + rem[i][j];
	   chd_b[i][j] = chd_b[i][j] + org[i][j] - rem[i][j];
	}
	
	/* printf("\nparent 1\n");
	for (i=0; i<k; ++i)
	{for (j=0; j<n; ++j)
	 printf(" %d ", par_a[i][j]);
	 printf("\n");
	}
	printf("\nparent 2\n");
	for (i=0; i<k; ++i)
	{for (j=0; j<n; ++j)
	 printf(" %d ", par_b[i][j]);
	 printf("\n");
	}
	printf("\nchild 1\n");
	for (i=0; i<k; ++i)
	{for (j=0; j<n; ++j)
	 printf(" %d ", chd_a[i][j]);
	 printf("\n");
	}
	printf("\nchild 2\n");
	for (i=0; i<k; ++i)
	{for (j=0; j<n; ++j)
	 printf(" %d ", chd_b[i][j]);
	 printf("\n");
	}*/

}
