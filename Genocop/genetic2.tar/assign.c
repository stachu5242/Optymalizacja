#include "genet.h"

assign_probabilities()
{
    Cost sum;
	int p;
	
	sum = 0;
	
	for (p = 0; p < pop; ++p)
	   sum = sum + (Cost)(pp[p]->eval);
	   
	
	for (p = 0; p < pop; ++p)
	   prob[p] = (double)(sum - pp[p]->eval)/((pop - 1)*sum);          
	                          
	                          
	for (p = 1; p < pop; ++p)
	   prob[p] = prob[p] + prob[p-1];
}













