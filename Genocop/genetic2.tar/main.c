#define EXTERN
#define TEST 0
#include "genet.h"
#define VERSION 	"version 4.3,  26 Jan 1989"
/* 4.3 - add tab output to loop:  change to _main and psf*/
#define BIG 999999
main()
{
	int	v = 0;
	int z;
	Cost best = BIG;
	Cost LastBest = BIG;
	seed0 = 1;
	k = 0;
	n = 0;
	optimum = MINUSINF;
	


	printf("%s\n", VERSION);

	while ( read_data() != EOF){ 
	    v = 0;
	    best=LastBest=BIG;
		reprod = cross + inver + mutat;

		initialize_population();
		

		while (v++ < it &&  best > optimum) {

# if TEST
			printf("loop\t%4d", v); printf("\n");
#endif

			evaluate_population();
			
			sort_population();
			
			assign_probabilities1();
			
			select_parents();
# if TEST
			print_iarray(parents); 
#endif
			select_dead();
# if TEST
			print_iarray(dead);	
#endif
			replace_population();
            
			best = pp[0]->eval;
			if (best < LastBest || v == it) {
				printf("loop\t%4d\t", v);
				print_so_far();
				LastBest = best;
			}


		      }

		print_results();
	
	}
	return(0);
}


