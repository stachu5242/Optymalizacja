#include "genet.h"


sort_population()
{
	bubble(pp,pop);
}

bubble(pp,m)
int m;
SOLN *pp [POP];
{
	int i,j;

	for (i=0;i<m-1;++i)
	for (j=m-1; i<j; --j)
   		order(pp,j-1,j);
}

order(pp,i,j)
SOLN *pp[];
int i,j;
{
	SOLN *temp;

	if (pp[i]->eval > pp[j]->eval)
   		{ temp = pp[i]; pp[i] = pp[j]; pp[j] = temp; }
}

