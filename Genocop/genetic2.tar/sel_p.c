/*-- select parents -- */

# include "genet.h"

double random_fr();

select_parents()
{
	int no_of_parents;
	int selected[POP];
	int p;
	double q;
	
	for (p=0; p< pop; ++p) parents[p] = 0;
	no_of_parents = 0;
	while (no_of_parents < reprod)
	{
	   q = random_fr();
	  
	   p = 0;
	   while (q > prob[p] && p < pop) p++;
	   if (p == pop) --p;
	   parents[p]++; 
	   no_of_parents++;
	 }
}



double random_fr() {
/* uses our own Rnd instead of rand (see rand.c) 
*	double a,b,c;
*	int d;
*	
*	c = licz;
*	
*	d = Rnd(); b=d;
*	a = b/c;
*
* on MacII, rand() returns an integer, on 3B2, a real (0-1)
*/
	
	return(rand()/licz); 
	
}

print_iarray(array)
int array[];
{
	int p;
	
	for ( p=0; p < pop; p++) printf("%d:  %d\n",p,array[p]);
	printf("\n");
}

print_darray(array)
double array[];
{
	int p;
	
	for ( p=0; p < pop; p++) printf("%d:  %f\n",p,array[p]);
	printf("\n");
}
