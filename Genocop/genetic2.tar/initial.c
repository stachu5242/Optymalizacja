#include "genet.h"

initialize_population()
{
	int p,i,j;
	int s[K],d[N];
	
	
	for (p = 0; p < pop; ++p)
	{
	   	pp[p] = &population[p];  /* initialise the pointer pp */

	    for (i=0; i<k; ++i) s[i] = sour[i];
		for (j=0; j<n; ++j) d[j] = dest[j];
	

	    init_one_population(k,n,s,d);
	   
	   	for (i = 0; i < k; ++i){
		for (j = 0; j < n; ++j){
			pp[p]->sol[i][j] = initial[i][j];
	                              }
	                            }
     }
  
 }
