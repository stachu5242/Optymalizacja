#include "genet.h"

print_so_far()
{
	int p;

	printf("value\t%9ld\n", pp[0]->eval);
	
}