#define TEST o
#include "genet.h"

mutate()

{
	int taken_col[N], taken_row[K], taken_row1[K], taken_col1[N]; 
	int row_tab[K], col_tab[N];
	int counter, counter_r, counter_c, sum, i,j,v;
	int r,c, r1, c1;
	
	for (i=0; i<k; ++i)
	for (j=0; j<n; ++j)
	   chd[i][j] = par[i][j];
	

	r = 0;
	while (r < 2) r = random0(k);
	c = 0;
	while (c < 2) c = random0(n);
	
	
	for (i = 0; i < k; ++i) {taken_row[i] = 0;}
	for (j = 0; j < n; ++j) {taken_col[j] = 0;}
	
#if TEST
	printf("enter select rows r = :%d\n",r);
#endif

	counter = 0;
	while (counter < r)
	{
	   r1 = random0(k); 
	   if (taken_row[r1] == 0) {counter++; taken_row[r1] = 1;}
	}
	
#if TEST
	printf("enter select cols c = :%d\n",c);
#endif

	counter = 0;
	while (counter < c)
	{
	   c1 = random0(n); 
	   if (taken_col[c1] == 0) {counter++; taken_col[c1] = 1;}
	}
	             
#if TEST
	printf("enter sum rows r = :%d\n",r);
#endif

	counter = -1;
	for (r1 = 0; r1 < k; ++r1)
	{ 
	   sum = 0;
	   if (taken_row[r1] == 1)
	   { 
		    counter = counter + 1;
		    for (v=0; v<n; ++v) {if (taken_col[v] == 1) sum = sum + par[r1][v];}
		                        
		    row_tab[counter] = sum;
	    }
	  } 
	
#if TEST
	printf("enter sum cols c = :%d\n",c);
#endif
	counter = -1;
	for (c1 = 0; c1 < n; ++c1)
	{
		sum = 0;
		if (taken_col[c1] == 1)
		{ 
			counter = counter + 1;
			for (v=0; v<k; ++v){ if (taken_row[v] == 1) sum = sum + par[v][c1];}
	                          
	    	col_tab[counter] = sum;
		}
	} 
	
	/* for (i=0; i<k; ++i){                                               
	/* for (j=0; j<n; ++j) {printf("%d   ", par[i][j]);} printf("\n");}   */
	/* printf("\n\n\n"); */
	
	/* printf("taken rows\n"); */
	/* for (i=0; i<k; ++i) printf("%d   ", taken_row[i]); */
	/* printf("\n"); */
	/* printf("taken columns\n"); */
	/* for (i=0; i<k; ++i) printf("%d   ", taken_col[i]); */
	/* printf("\n\n\n"); */
	
	/* printf("row sums\n"); */
	/* for (i=0; i<r; ++i) printf("%d   ", row_tab[i]); */
	/* printf("\n\n\n"); */
	
	/* printf("col sums\n"); */
	/* for (i=0; i<c; ++i) printf("%d   ", col_tab[i]); */
	/* printf("\n\n\n"); */
	
#if TEST
	printf("enter init population\n");
#endif

	init_one_population(r,c, row_tab, col_tab);

#if TEST
	printf("leave init population\n");
#endif
	
	/* printf("\n i n i t i a l \n"); */
	/* for (i=0; i<r; ++i){ */
	/* for (j=0; j<c; ++j) printf("%d   ", initial[i][j]); printf("\n");} */
	/* printf("\n\n\n"); */
	    
	
#if TEST
	printf("enter copy back\n");
#endif
	counter_r = -1;   
	for (i =0; i<k; ++i)
	   {
		    counter_c = -1;
		    if (taken_row[i] == 1) 
		       {
			        counter_r = counter_r +1;
			        for (v=0; v<n; ++v)
			           {
				            if (taken_col[v] == 1) 
				               {
					                counter_c = counter_c +1;
					                chd[i][v] = initial[counter_r][counter_c];
				                }
			            }
		        }
	    }
	/* for (i=0; i<k; ++i){ */
	/* for (j=0; j<n; ++j) printf("%d   ", chd[i][j]); printf("\n");} */
}
                                 






