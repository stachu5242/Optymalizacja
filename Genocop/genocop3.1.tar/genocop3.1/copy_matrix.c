#include "genocop.h"

#if DOS_SYS
  extern FILE *input,*output;
#endif


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   copy_matrix()                                */
/*                                                                              */
/*           SYNOPSIS          :   void copy_matrix(mat1,mat2,lr,ur,lc,uc)      */
/*                                                                              */
/*           DESCRIPTION       :   This function makes a duplicate of a given   */
/*                                  float matrix                                */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   p_equalities()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/




void copy_matrix(mat1,mat2,lr,ur,lc,uc)
int lr,ur,lc,uc;
MATRIX mat1,mat2;
{
  int i,j;

  for(i=lr; i<=ur; i++)
    for(j=lc; j<=uc; j++)
      mat2[i][j] = mat1[i][j];
}
