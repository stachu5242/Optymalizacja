#include "genocop.h"

#if DOS_SYS
extern FILE *input,*output;
extern int test_num;
#endif

/* Cummulative probability on crossover */
/* Random probability on mutation       */
/* NO multiple hits per agent possible  */


/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   optimization()                               */
/*                                                                              */
/*           SYNOPSIS          :   void optimization(X,x1,x2,fin_mat,rc,tot_eq) */
/*                                                                              */
/*           DESCRIPTION       :   This procedure initializes the population    */
/*                                  with the values X passed from main, and     */
/*                                  evaluates them.  After assigning weight     */
/*                                  for each member of the populaiton, a group  */
/*                                  of them are chosen to reproduce and a group */
/*                                  is chosen to die.  Genetic operators are    */
/*                                  applied and a new generation is produced    */
/*                                  to replace the members that died.  This     */
/*                                  cycle continues for the number of times,    */
/*                                  user specifies in the input file            */
/*                                                                              */
/*           FUNCTIONS CALLED  :   assign_probab(),                             */
/*                                 evaluate(),                                  */
/*                                 find_cum_probab(),                           */
/*                                 find_live_die(),                             */
/*                                 find_parent(),                               */
/*                                 ivector(),                                   */
/*                                 matrix(),                                    */
/*                                 oper1(),                                     */
/*                                 oper2(),                                     */
/*                                 oper3(),                                     */
/*                                 oper4(),                                     */
/*                                 oper5(),                                     */
/*                                 oper6(),                                     */
/*                                 print_matrix(),                              */
/*                                 print_population(),                          */
/*                                 sort(),                                      */
/*                                 vector().                                    */
/*                                                                              */
/*           CALLING FUNCITONS :   main()                                       */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

void optimization(X,x1,x2,fin_mat,rc,tot_eq,a1_b)
MATRIX fin_mat;
VECTOR X,a1_b;
IVECTOR x1,x2;
INDEX rc;
int tot_eq;
{
  MATRIX new_agents,   /*Temporary storage for the new agents*/
         population,   /*Population of x2 variables*/
         print_pop,
         temp;

  VECTOR probab,       /*Probability of agents to die or live*/
         cum_probab,   /*Cumulative probability of agents*/
         cum_prob_op,  /*Cumulative probability of operators*/
         t_vec,
         P;            /*Probability of operators*/

  IVECTOR live,
          die,
          oper_count;   /*frequencies for applying operators*/


  unsigned long generations;    /*Total number of Generations*/
  unsigned long count_gener= 1; /*Counter to keep track of the number of generations*/
  unsigned long peak_cnt;

  int pop_size,         /*Population size*/
      MinMax,           /*Minimization or Maximization problem 0 or 1 */
      init_val,		/*Single or multiple point init. population? */
      oper,             /*Operator number*/
      B,                /*Parameter for the 3rd operator - nonuniform mutation*/
      STEP,   /*Parameter for the 5th operator - simple arithmetical crossover*/
      x2_vari = rc.c-2,
      first,            /*Index of the parent to mutate*/
      first_live,       /*Index of the two parents for crossover parents*/
      second_live,
      first_die,        /*Index of the two parents for crossover death*/
      second_die,
      replace,          /*Index of the replaced agent*/
      tot,              /*total number of chosen parents not used*/
      i,
      j,
      k,
      dup_count;        /* replication count */

  int counter1 = 10,
      counter2 = 10,
      counter3 = 10,
      counter6 = 10;

  float Q,    /*Probability of the best agent*/
        A,    /*Parameter for the 4th operator - whole arithmetical cross over*/
        Teval,      /*Evaluation of the best agent*/
        initial_val,/*Initial value of the population */
        init_prob,  /*Initial value of the probability */
        peak_val;

  int x,y;


  FLAG  same;
  FLAG  _PROGEND;
  FLAG  improve;     /*check if the operator generates a better child*/

  FLAG  condit1;    /*check condition to see if the newly created vectors*/ 
  FLAG  condit2;    /*satisfies the set of constraints                   */
  FLAG  condit3; 
  FLAG  condit6;

  float**new;

  char response_char;
  

  /*Reading from the file the population size, total number of generations, total number*/
  /*of times each of the 5 operators to be applied, probability of the best agent,*/
  /*minimization or maximization problem, the parameters for the operators*/
  fscanf(input,"%d %u",&pop_size,&generations);
  fscanf(input,"%f ",&Q);
  fscanf(input,"%d ",&MinMax);
  fscanf(input,"%d ",&init_val);
  fscanf(input,"%d ",&B);
  fscanf(input,"%d ",&STEP);
  fscanf(input,"%d ",&test_num);
  fclose(input);

  fprintf(output,"\n\n");
  fprintf(output,"Test case number      : %d\n", test_num);
  fprintf(output,"Number of generations : %lu\n",generations);
  fprintf(output,"Population size       : %d\n", pop_size);
  fprintf(output,"Parameter B           : %d\n", B);
  fprintf(output,"Parameter Q           : %f\n", Q);


  peak_val = 0;
  peak_cnt = 0;

  /*Space allocation for all the vectors and matrices involved*/
  population  = matrix(1,pop_size,0,x2_vari+1);
  print_pop   = matrix(1,pop_size,0,x2_vari+tot_eq+1);
  new_agents  = matrix(1,2,0,x2_vari+1);
  temp        = matrix(1,2,1,x2_vari);
  probab      = vector(1,pop_size);
  P           = vector(1,7);
  t_vec       = vector(1,x2_vari);
  cum_probab  = vector(1,pop_size);
  cum_prob_op = vector(1,7);
  live        = ivector(1,pop_size);
  die         = ivector(1,pop_size);
  oper_count  = ivector(1,7);


  /*Initial population with all identical agents, whose values were got randomly*/
  if (init_val == 1)
  {
  fprintf(output, "\n\nUSING SINGLE POINT INITIAL POPULATION...\n\n");
    _PROGEND = initialize_x2(fin_mat,rc,x1,x2,tot_eq,X,a1_b);

  for(j=1; j<=pop_size; j++)
  {
    for(i=1; i<=x2_vari; i++)
      {
        population[j][i] = X[x2[i]];
        population[j][x2_vari+1] = 0;
      }
     population[j][0] = evaluate(X);
  }
  fprintf(output,"\nThe initial point of the population is\n");
  print_vector(X,1,tot_eq+x2_vari);
  } /* end of if init_val == 1*/
  else
  {
  fprintf(output, "\n\nUSING MULTIPLE POINT INITIAL POPULATION...\n\n");

  j = 1;
  while (j<=pop_size)
  {
    _PROGEND = initialize_x2(fin_mat,rc,x1,x2,tot_eq,X,a1_b);
    if (_PROGEND == TRUE)
    {
    for(i=1; i<=x2_vari; i++)
      {
        population[j][i] = X[x2[i]];
        population[j][x2_vari+1] = 0;
      }
     j++;

    }
    else 
    {
      printf("Do you wish to include/replicate this vector in the population? (y/n)");
      fflush(stdin);
      response_char = getchar();
      fflush(stdin);
      if (response_char=='Y' || response_char=='y')
      {
        	do{ 
	      	printf("How many copies (min. 1, max. %d) :", pop_size-j+1);        	
		  	scanf("%d", &dup_count);
		  	if ((dup_count < 1) || (dup_count > (pop_size-j+1)))
  			printf("\nInvalid entry.  Must be in the range 1 to %d\n",
  			pop_size-j+1);
		  	} while ((dup_count < 1) || (dup_count > (pop_size-j+1)));
  	
  	
       	for (k=1; k<=dup_count; k++)
      	{
      	    for(i=1; i<=x2_vari; i++) {
	      		population[j][i] = X[x2[i]];
	      		population[j][x2_vari+1] = 0;
	      	}
      		j++;
      	} /* end of for dup_count.... */
      		
      } /* end of if response_char...... */
    }    /* end of if _PROGEND...else.............. */
   }/* end of do loop */
  }   /* end of if in_val.....else.................*/ 


/*********** eval. and sort first generation *************************/

      for(i=1; i<=pop_size; i++)
        {
          /*if (population[i][x2_vari+1] != 0) */      /* do not reevaluate if no changes were made */
            {
              if (tot_eq != 0)
                {
                  for(j=1; j<=x2_vari + tot_eq; j++)
                    X[j] = 0.0;

                  find_X(fin_mat,population[i],X,x2_vari,tot_eq,x1,x2,a1_b);
                }
              else
                for(j=1; j<=x2_vari; j++)
                   X[j] = population[i][j];

              population[i][0] = evaluate(X);       
            } 
        }


  /* Evaluate the best in population and assign it to Teval */
      sort(MinMax,population,pop_size);
        
/*****************************************************************/

  fprintf(output,"\n\n");
  fprintf(output,"\n\nGeneration#\t    Solution Value\n");


  /*Assigning probability of survival for each of the agent, with the*/
  /*probability provided by the user for the best agent*/
  assign_probab(probab,pop_size,Q);

  /*Finding the cumulative probability of the agents*/
  find_cum_probab(cum_probab,probab,pop_size);
     
  Teval = population[1][0]; peak_val=population[1][0];

  /*initialize the probability vector for operators*/
  init_prob = (float) 1 / 7;
  for(i=1; i<=7; i++)
    P[i] = init_prob;

  /*initialize the frequency vector for operators*/
  for(i=1; i<=7; i++)
     oper_count[i] = 0;


  /*Reproducing and evaluating for the total number of generations times*/
  do
    {
      /*Initializing the live and die vectors*/
      for(j=1; j<=pop_size; j++)
         live[j] = die[j] = 0;

      /*initialize the new agents matrix*/
      for(i=1; i<=2; i++)
         for(j=0; j<=x2_vari+1; j++)
            new_agents[i][j] = 0.0;

      /*Finding the cumulative probability of the operators*/
      find_cum_probab(cum_prob_op,P,7);

      /*finding the agents that will reproduce*/
      find_live(cum_probab,live,pop_size,2);

      /*initialize the index of the die agent*/
      replace = 0;

      /*initialize the flag improve*/
      improve = 0;

      oper = find_oper(cum_prob_op);

      switch (oper)
      {
        case 1:        /*Applying the first operator, uniform mutation,*/
                       /*for the number of times specified*/
                do     /*reselect parent if condit1 is not satified*/ 
                {
                  do
                    first = irange_ran(2,pop_size);
                  while (die[first] == 1);
                  die[first] = 1;

                  for(i=1; i<=x2_vari; i++)
                     t_vec[i] = population[first][i];
                  condit1 = oper1(t_vec,fin_mat,rc);

                  if (condit1)
                  {
                    new_agents[1][x2_vari+1] = 1.0;
                    for(i=1; i<=x2_vari; i++)
                       new_agents[1][i] = t_vec[i];
                  }
                  else
                    counter1--;
                } while ((!condit1) && (counter1 > 0));
                break;
        case 2:         /*Applying the second operator, boundary mutation,*/
                        /*for the number of times specified*/
                do      /*reselect parent if condit2 is not satified*/
                {
                   do
                     first = irange_ran(2,pop_size);
                   while (die[first] == 1);
                   die[first] = 1;

                   for(i=1; i<=x2_vari; i++)
                      t_vec[i] = population[first][i];
                   condit2 = oper2(t_vec,fin_mat,rc);

                   if (condit2)
                   {
                      new_agents[1][x2_vari+1] = 2.0;
                      for(i=1; i<=x2_vari; i++)
                         new_agents[1][i] = t_vec[i];
                   }
                   else
                      counter2--;
                } while ((!condit2) && (counter2 > 0));
                break;
        case 3:         /*Applying the third operator, non-uniform mutation,*/
                        /*for the number of times specified*/
                do      /*reselect parent if condit3 is not satified*/
                {
                    do
                      first = irange_ran(2,pop_size);
                    while (die[first] == 1);
                    die[first] = 1;

                    for(i=1; i<=x2_vari; i++)
                       t_vec[i] = population[first][i];
                    condit3 = oper3(t_vec,fin_mat,rc,generations,count_gener,B); 
                    if (condit3)
                    {
                       new_agents[1][x2_vari+1] = 3.0;
                       for(i=1; i<=x2_vari; i++)
                          new_agents[1][i] = t_vec[i];
                    }
                    else
                       counter3--;
                } while ((!condit3) && (counter3 > 0));
                break;

        case 4: /*Applying the fourth operator, whole arithmetical crossover*/
                /*Find two distinct parents for crossover operator 4*/
                first_live  = find_parent(live,pop_size);
                second_live = find_parent(live,pop_size);
                same = TRUE;
                for(i=1; i<=x2_vari; i++)
                   if(population[first_live][i] != population[second_live][i])
                     same = FALSE;
                   if(!same)
                   {
                     first_die   = find_die(cum_probab, die ,pop_size);
                     second_die  = find_die(cum_probab, die ,pop_size);
                     die[first_die]  = 1;
                     die[second_die] = 1;
                     new_agents[1][x2_vari+1] = 4.0;
                     new_agents[2][x2_vari+1] = 4.0;
                     for(i=1; i<=x2_vari; i++)
                     {
                        temp[1][i] = population[first_live][i];
                        temp[2][i] = population[second_live][i];
                     }
                     oper4(temp[1],temp[2],x2_vari); 

                     for(i=1; i<=x2_vari; i++)
                     {
                        new_agents[1][i] = temp[1][i];
                        new_agents[2][i] = temp[2][i];
                     }
                   }
                break;
        case 5: /*Applying the fifth operator, simple arithmetical crossover*/
                /*Find two distinct parents for crossover operator 5*/
                first_live  = find_parent(live,pop_size);
                second_live = find_parent(live,pop_size);
                same = TRUE;
                for(i=1; i<=x2_vari; i++)
                   if(population[first_live][i] != population[second_live][i])
                     same = FALSE;
                if(!same)
                {
                  first_die   = find_die(cum_probab, die ,pop_size);
                  second_die  = find_die(cum_probab, die ,pop_size);
                  die[first_die]  = 1;
                  die[second_die] = 1;
                  new_agents[1][x2_vari+1] = 5.0;
                  new_agents[2][x2_vari+1] = 5.0;
                  for(i=1; i<=x2_vari; i++)
                  {
                     temp[1][i] = population[first_live][i];
                     temp[2][i] = population[second_live][i];
                  }
                  oper5(temp[1],temp[2],STEP,rc,fin_mat); 

                  for(i=1; i<=x2_vari; i++)
                  {
                     new_agents[1][i] = temp[1][i];
                     new_agents[2][i] = temp[2][i];
                  }
                }
                break;
        case 6: /*Applying the sixth operator, whole non-uniform mutation,*/
                /*for the number of times specified*/
                do        /*reselect parent if condit6 is not satified*/
                {
                   do
                     first = irange_ran(2,pop_size);
                   while (die[first] == 1);
                   die[first] = 1;

                   for(i=1; i<=x2_vari; i++)
                      t_vec[i] = population[first][i];
                   condit6 = oper6(t_vec,fin_mat,rc,generations,count_gener,B); 
                   if(condit6)
                   {
                     new_agents[1][x2_vari+1] = 6.0;
                     for(i=1; i<=x2_vari; i++)
                        new_agents[1][i] = t_vec[i];
                   }
                   else
                     counter6--;
                } while ((!condit6) && (counter6 > 0));
                break;
        case 7: /*Applying the seventh operator*/
                /*Find two distinct parents for operator 7*/
                first_live  = find_parent(live,pop_size);
                second_live = find_parent(live,pop_size);
                same = TRUE;
                for(i=1; i<=x2_vari; i++)
                   if(population[first_live][i] != population[second_live][i])
                     same = FALSE;
                if(!same)
                {
                  first   = find_die(cum_probab, die ,pop_size);
                  die[first]  = 1;
                  new_agents[1][x2_vari+1]  = 7.0;
                  new_agents[2][x2_vari+1]  = 0.0;
                  for(i=1; i<=x2_vari; i++)
                     if(first_live < second_live)/*first agent is better agent*/
                     {
                       temp[2][i] = population[first_live][i];
                       temp[1][i] = population[second_live][i];
                     }
                     else                        /*second agent is better agent*/
                     {
                       temp[2][i] = population[second_live][i];
                       temp[1][i] = population[first_live][i];
                     }
                  oper7(temp[1],temp[2],rc,fin_mat);

                  for(i=1; i<=x2_vari; i++)
                     new_agents[1][i]  = temp[1][i];
                }
                break;
       default: printf("default\n");
    }

    /*Evaluation, update operator probabilities(reward), and do replacement*/
    if((new_agents[1][x2_vari+1] != 0.0) && (new_agents[2][x2_vari+1] == 0.0))
    {
      eval_child(fin_mat, new_agents[1], X, x2_vari, tot_eq, x1, x2, a1_b);
      switch (MinMax)
      {
          case 0:
                   if(new_agents[1][0] < population[first][0])
                   {
                     update_prob(population[first],new_agents[1],P,x2_vari,oper);
                     replace = first;
                     improve = 1;
                   }
                   break; 
          case 1:
                   if(new_agents[1][0] > population[first][0])
                   {
                     update_prob(population[first],new_agents[1],P,x2_vari,oper);
                     replace = first;
                     improve = 1;
                   }
                   break;
          default: printf("default in MinMax\n");
      }
    }
    if((new_agents[1][x2_vari+1] != 0.0) && (new_agents[1][x2_vari+1] == new_agents[2][x2_vari+1]))
    {
      for(i = 1; i <= 2; i++)
         eval_child(fin_mat, new_agents[i], X, x2_vari, tot_eq, x1, x2, a1_b);
      switch (MinMax)
      {
          case 0:
                   if(new_agents[1][0] < population[first_live][0])
                   {
                     update_prob(population[first_die],new_agents[1],P,x2_vari,oper);
                     replace = first_die;
                     improve = 1;
                   }
                   else if(new_agents[2][0] < population[second_live][0])
                   {
                     update_prob(population[second_die],new_agents[2],P,x2_vari,oper);
                     replace = second_die;
                     improve = 1;
                   }
                   break; 
          case 1:
                   if(new_agents[1][0] > population[first_live][0])
                   {
                     update_prob(population[first_die],new_agents[1],P,x2_vari,oper);
                     replace = first_die;
                     improve = 1;
                   }
                   else if(new_agents[2][0] > population[second_live][0])
                   {
                     update_prob(population[second_die],new_agents[2],P,x2_vari,oper);
                     replace = second_die;
                     improve = 1;
                   }
                   break;
          default: printf("default in MinMax\n");
      }
    }      


    /*Sort the new population based on their evaluation function*/
    /*and rebalance the vector P for appropriate case (penalty) */
    switch (improve)
    {
          case 0:
                   if(oper_count[oper] < NO_IMPROV_TIME)
                     oper_count[oper]++;
                   else if(P[oper] > init_prob)
                   {
                     rebalance(P, init_prob, oper);

                     oper_count[oper] = 0;
                   }
                   break;
          case 1:
                   oper_count[oper] = 0;
                   part_sort(MinMax,population,pop_size,replace);
                   break;
         default:  fprintf(output, "improve value is wrong\n");
    }

    switch(MinMax)
    {
     case 0:
            if(Teval > population[1][0])
            {
              Teval = population[1][0];
              fprintf(output,"%7lu \t%18.8f\n",count_gener,population[1][0]);
              peak_cnt = count_gener;
              peak_val = population[1][0];
            }
            break;
     case 1:
            if(Teval < population[1][0])
            {
              Teval = population[1][0];
              fprintf(output,"%7lu \t%18.8f\n",count_gener,population[1][0]);
              peak_cnt = count_gener;                
              peak_val = population[1][0];
            }
            break;
        }
#if DOS_SYS
      gotoxy(5,7);
#endif
      /*Increment the number of iteration*/
      count_gener++;
  } while (count_gener <= generations);


  fprintf(output, "\nBest solution was found at generation %lu (solution value = %.8f)\n", peak_cnt,peak_val);
  fprintf(output,"\n\nBest solution found:\n\n");

  /* print best solution */
  find_X(fin_mat,population[1],X,x2_vari,tot_eq,x1,x2,a1_b);
  for(j = 1; j <= x2_vari+tot_eq; j++)
    fprintf(output," X[%2d] :\t%18.8f\n",j,X[j]);

    free_matrix(population ,1,pop_size,0);
    free_matrix(print_pop  ,1,pop_size,0);
    free_matrix(new_agents ,1,2,0);
    free_matrix(temp       ,1,2,1);
    free_vector(probab     ,1);
    free_vector(P          ,1);
    free_vector(t_vec      ,1);
    free_vector(cum_probab ,1);
    free_vector(cum_prob_op,1);
    free_ivector(live      ,1);
    free_ivector(die       ,1);
    free_ivector(oper_count,1);

}

/********************************************************************************/
/*           FUNCTION NAME     : rebalance()                                    */
/*           SYNOPSIS          : void rebalance(P, init_prob, oper)             */
/*           DESCRIPTION       : This function panelize an operator if it has   */ 
/*                               been applied NO_IMPROV_TIME times and made no  */
/*                               improvement. Then it rebalances the panelized  */
/*                               amount to the rest of the operators.           */
/*           FUNCTIONS CALLED  : none                                           */
/*           CALLING FUNCTIONS : optimization()                                 */
/*           AUTHOR            : Li Cui                                         */
/*           DATE              : 09/25/96                                       */
/*                                                                              */
/*           REV              DATE              BY            DESCIRPTION       */
/*           ---              ----              --            -----------       */
/********************************************************************************/

void rebalance(P, init_prob, oper)
VECTOR P;
float  init_prob;
int    oper;
{
  IVECTOR high_prob;
  int   i, count = 0;
  float temp1, temp2, temp3;

  high_prob = ivector(1,7);  /*allowcate storage for vector high_prob*/

  for(i = 1; i <= 7; i++)
     high_prob[i] = 0;

  temp1 = (float) (P[oper] - init_prob) / 3 * 2;
  temp2 = (float) temp1 / 6;
  
  P[oper] = P[oper] - temp1;

 do
  {
    temp3 = 0.0;
    for(i = 1; i <= 7; i++)
       if((i != oper) && (high_prob[i] != 1))
       {
         P[i] = P[i] + temp2;
         if(P[i] > UP_PROB)           /* if the current prob. is over UP_PROB,*/
         {                            /* replace the current prob. with the   */
           P[i] = P[i] - temp2;       /* orginal prob. and distribute this    */
           temp3 = temp3 + temp2;     /* amount evenly to other operators' not*/
           high_prob[i] = 1;          /* including the one that need a reward */
           count++;
         }
       }
    temp2 = temp3 / (6 - count);
  } while(temp3 != 0.0);

  free_ivector(high_prob  ,1);
}

/*********************************************************************************/
/*         FUNCTION NAME     : eval_child()                                      */
/*         SYNOPSIS          : void eval_child(fin_mat,agent,X,X2_vari,tot_eq,x1 */ 
/*                                             ,x2,a1_b)                         */
/*         DESCRIPTION       : This function evaluates the child generated by    */
/*                             applying one of the seven operators.              */
/*         FUNCTIONS CALLED  : none                                              */
/*         CALLING FUNCTIONS : optimization()                                    */
/*         AUTHOR            : Li Cui                                            */
/*         DATE              : 09/24/96                                          */
/*                                                                               */
/*         REV             DATE                  BY            DESCRIPTIONS      */
/*         ---             ----                  --            ------------      */
/*********************************************************************************/


void eval_child(fin_mat, agent, X, x2_vari, tot_eq, x1, x2, a1_b)
MATRIX fin_mat;
VECTOR  agent, X, a1_b;
IVECTOR x1, x2;
int     x2_vari, tot_eq;
{
  int j;
 
  if(tot_eq != 0)
  {
    for(j = 1; j <= x2_vari + tot_eq; j++)
       X[j] = 0.0;
    find_X(fin_mat,agent,X,x2_vari,tot_eq,x1,x2,a1_b);
  }
  else
    for(j = 1; j <= x2_vari; j++)
       X[j] = agent[j];
 
  agent[0] = evaluate(X);
 
}

/*******************************************************************************
*/
/*         FUNCTION NAME     : update_prob()
*/
/*         SYNOPSIS          : void update_prob(popula,agent,P,x2_vari,oper)
*/
/*         DESCRIPTION       : This function rewards the operator that has 
*/
/*                             generated a child which is better than its 
*/
/*                             parent and panlizes all other operators whose
*/  
/*                             probabilities are not below the LOW_PROB.
*/
/*                             This function also replace the agent choosen to
*/                    
/*                             be die with the new agent.  
*/
/*         FUNCTIONS CALLED  : none
*/
/*         CALLING FUNCTIONS : optimization()
*/
/*         AUTHOR            : Li Cui
*/
/*         DATE              : 09/24/96
*/
/*
*/
/*         REV             DATE                  BY            DESCRIPTIONS     
*/
/*         ---             ----                  --            ------------     
*/
/*******************************************************************************
*/


void update_prob(popula,agent,P,x2_vari,oper)
VECTOR popula, agent, P;
int    x2_vari, oper;
{
  IVECTOR low_prob;
  int     i, j, low_prob_no = 0, count;
  float   prob_incre, prob_decre;
  float   temp, temp1;

  low_prob = ivector(1,7);  /*allowcate storage for vector low_prob*/
 
  /*update the vector of low_prob*/
  for(i = 1; i <= 7; i++)
     if(P[i] <= LOW_PROB)
       low_prob[i] = 1;
     else
       low_prob[i] = 0;
 
  /*compute the number of operators with probabilites below LOW_PROB*/
  for(i = 1; i <= 7; i++)
     if(i != oper)
       low_prob_no = low_prob_no + low_prob[i];
 
  /*the increasing amount of probability*/
  prob_incre = (0.5 - P[oper]) / 2;

  /*the decreasing amount of probability for each operator*/
  prob_decre = prob_incre / (6 - low_prob_no);

  /*replace the died agent with the new agent*/
  for(j = 0; j <= x2_vari + 1; j++)
     popula[j] = agent[j];

  P[oper] = P[oper] + prob_incre;
  temp = prob_decre;
  do
  {
    temp1 = 0.0;
    for(i = 1; i <= 7; i++)
       if((i != oper) && (low_prob[i] != 1))
       {
         P[i] = P[i] - temp;
         if(P[i] < LLOW_PROB)         /*replace the current prob. with the */
         {                            /*orginal prob. if the current prob. is*/
           P[i] = P[i] + temp;        /*below LLOW_PROB and distribute this*/
           temp1 = temp1 + temp;      /*amount evenly to other operators not*/
           low_prob[i] = 1;           /*including the one which need a reward*/
           low_prob_no++;
         }
       } 
    if(low_prob_no == 6)
    {
      P[oper] = P[oper] - prob_incre;
      break;
    }
    temp = temp1 / (6 - low_prob_no);
  } while(temp1 != 0.0);

  free_ivector(low_prob  ,1);
}

/*******************************************************************************
*/
/*
*/
/*           FUNCTION NAME     :   part_sort()
*/
/*
*/
/*           SYNOPSIS          :   void part_sort(MinMax, population,pop_size,
*/
/*                                 die)
*/
/*
*/
/*           DESCRIPTION       :   This function partially sorts the population
*/
/*                                 , from the position of died agent to the
*/
/*                                 best agent, in the ascending or the
*/
/*                                 descending order of the evaluation function,
*/
/*                                 depending on whether it is a maximization or
*/
/*                                 a minimization function, respectively.
*/
/*
*/
/*           FUNCTIONS CALLED  :   swap()
*/
/*
*/
/*           CALLING FUNCITONS :   optimization()
*/
/*
*/
/*           AUTHOR            :   Swarnalatha Swaminathan
*/
/*
*/
/*           DATE              :   1/17/92
*/
/*
*/
/*
*/
/*           REV            DATE            BY           DESCRIPTION
*/
/*           ---            ----            --           -----------
*/
/*          A               9/11/92       Tom Logan      Rewrote
*/
/*          B               9/24/96        Li Cui        Simplyfied
/*
*/
/*******************************************************************************
*/
void part_sort(MinMax,population,pop_size,die)
int MinMax,       /*Tells whether it is a maximizaiton or a minimization function*/
    die,          /*Index shows which agent is die*/
    pop_size;     /*Population size*/
MATRIX population;/*Array of population*/
{
  int i;


  /*If MinMax is 0 sorts in the descending order, and*/
  /*if it is 1 sorts in the ascending order*/
  /*Sorted in ascending or descending order, based on*/
  /*the evaluated values of each of the agents*/
  switch(MinMax)
    {
    case 0 :
      for(i=die; i>=2; i--)
         if(population[i][0] < population[i - 1][0])
           swap(&population[i],&population[i - 1]);
         else
           break;
      break;

    case 1 :
      for(i=die; i>=2; i--)
         if(population[i][0] > population[i - 1][0])
            swap(&population[i],&population[i - 1]);
         else
            break;
      break;
    default:
      fprintf(output,"Incorrect data: Must be a 0 or 1");
      exit(1);
    }
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   sort()                                       */
/*                                                                              */
/*           SYNOPSIS          :   void sort(MinMax, population,pop_size)       */
/*                                                                              */
/*           DESCRIPTION       :   This function sorts the population, in the   */
/*                                  ascending or the descending order of the    */
/*                                  evaluation function, depending on whether   */
/*                                  it is a maximization or a minimization      */
/*                                  function, respectively.                     */
/*                                                                              */
/*                                  As an alternative, the sortq function below */
/*                                  can be used, That sorting function uses     */
/*                                  the quicksort algorithm.                    */
/*                                                                              */
/*                                                                              */
/*           FUNCTIONS CALLED  :   swap()                                       */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*          A               9/11/92       Tom Logan      Rewrote                */
/*                                                                              */
/********************************************************************************/
void sort(MinMax,population,pop_size)
int MinMax,       /*Tells whether it is a maximizaiton or a minimization function*/
    pop_size;     /*Population size*/
MATRIX population;/*Array of population*/
{
  int i,j,k;


  /*If MinMax is 0 sorts in the descending order, and*/
  /*if it is 1 sorts in the ascending order*/
  /*Sorted in ascending or descending order, based on*/
  /*the evaluated values of each of the agents*/
  switch(MinMax)
    {
    case 0 :
      for(i=1; i<=pop_size; i++)
        for(j=i+1; j<=pop_size; j++)
          if(population[i][0] > population[j][0])
            swap(&population[i],&population[j]);
      break;

    case 1 :
      for(i=1; i<=pop_size; i++)
        for(j=i+1; j<=pop_size; j++)
          if(population[i][0] < population[j][0])
            swap(&population[i],&population[j]);
      break;
    default:
      fprintf(output,"Incorrect data: Must be a 0 or 1");
      exit(1);
    }
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   swap()                                       */
/*                                                                              */
/*           SYNOPSIS          :   void swap(x,y)                               */
/*                                                                              */
/*           DESCRIPTION       :   This function interchanges the values of     */
/*                                  x and y.                                    */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   sort()                                       */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/



void swap(x,y)
float **x,**y;
{
  float *temp;

  temp = *x;
  *x = *y;
  *y = temp;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_parent()                                */
/*                                                                              */
/*           SYNOPSIS          :   int find_parent(live,pop_size)               */
/*                                                                              */
/*           DESCRIPTION       :   This function returns the index of the       */
/*                                  agent in the population, which is to be     */
/*                                  chosen for reproduction.                    */
/*                                                                              */
/*           FUNCTIONS CALLED  :   irange_ran()                                 */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/

int find_parent(live,pop_size)
int pop_size; /*Population size*/
IVECTOR live; /*Vector containing the number of times each agent*/
              /*is going to reproduce*/
{
  int i,temp,t1,tot=0;

  /*Finding the total number of parents to reproduce*/
  for(i=1; i<=pop_size; i++)
    tot = tot + live[i];
  if(tot==0)
    {
      printf("No agents to select\n");
      exit(1);
    }

  /*Choosing one of them randomly*/
  temp = irange_ran(1,tot);

  tot = 0;
  i = 1;
  do{
    if(live[i]!=0)
      t1 = i;
    tot = tot + live[i++];
  }while(tot<temp);

  /*Decrementing the number of times the parent chosen is going to reproduce*/
  live[t1]--;
  return(t1);
}
/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   assign_probab()                              */
/*                                                                              */
/*           SYNOPSIS          :   void assign_probab(probab,pop_size,Q)        */
/*                                                                              */
/*           DESCRIPTION       :   This function assigns probability of survival*/
/*                                  to each of the agents determined by the     */
/*                                  value provided by the user for the          */
/*                                  probability of the best agnet.              */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/


void assign_probab(probab,pop_size,Q)
int pop_size;  /*Population size*/
double Q;       /*The probability of survival of the best agent*/
VECTOR probab; /*Array to contain the probability of survival*/
               /* of each of the agents*/
{
  int i;
  double Q1;

  /* Q, Q(1-Q)^1, Q(1-Q)^2 ... Q(1-Q)^n */
  Q1 = Q/(1 - x_pow_y(1-Q,pop_size));
  for(i=1; i<=pop_size; i++)
    probab[i] = Q1 * x_pow_y(1-Q,i-1);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   x_pow_y()                                    */
/*                                                                              */
/*           SYNOPSIS          :   float x_pow_y(x,y)                           */
/*                                                                              */
/*           DESCRIPTION       :   This function returns the value of x to the  */
/*                                  power of y.                                 */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   assign_probab()                              */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/



float x_pow_y(x,y)
float x;
int y;
{
  int i;
  float tot = 1.0;

  for(i=0; i < y; i++)
    tot = tot * x;
  return(tot);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_cum__probab()                           */
/*                                                                              */
/*           SYNOPSIS          :   void find_cum__probab(cum_probab,probab,     */
/*                                                                     pop_size)*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the cumulative           */
/*                                  probability of each of the agents, from the */
/*                                  individual probability found earlier.       */
/*                                                                              */
/*           FUNCTIONS CALLED  :   None                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/



void find_cum_probab(cum_probab,probab,pop_size)
int pop_size;     /*Population size*/
VECTOR probab,    /*Individual probability of survival of each of the agent*/
       cum_probab;/*Cumulative probability of survival of each of the agent*/
{
  int i;

  cum_probab[1] = probab[1];

  for(i=2; i<=pop_size; i++)
    cum_probab[i] = cum_probab[i-1] + probab[i];

}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_oper()                                  */
/*                                                                              */
/*           SYNOPSIS          :   int find_oper(cum_prob_op)                   */
/*                                                                              */
/*           DESCRIPTION       :   This function returns the operator from seven*/
/*                                  operators, which is going to apply to those */
/*                                  agents who are going to reproduce, based on */
/*                                  the cumulative probability of frenquency of */
/*                                  applying each of the operators.             */
/*                                                                              */
/*           FUNCTIONS CALLED  :   frange_ran()                                 */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Li Cui                                       */
/*                                                                              */
/*           DATE              :   9/11/96                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/



int find_oper(cum_prob_op)
VECTOR cum_prob_op; /*Cumulative probability for operators*/
{
  float random;
  int i;         /*counter*/

  /*Choosing a random cumulative probability*/
  random = frange_ran(0.0,1.0);
  i=0;
  /*Finding the operator with the chosen cumulative probability*/
  do{
    i++;
    }while((random > cum_prob_op[i]) && (i < 7));

  return i;
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_live()                                  */
/*                                                                              */
/*           SYNOPSIS          :   void find_live(cum_probab,live,pop_size,P4+P5*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the agents from the      */
/*                                  population, who are going to live - those   */
/*                                  who are going to reproduce, which is done   */
/*                                  based on the cumulative probability of      */
/*                                  survival of each of the agents.             */
/*                                                                              */
/*           FUNCTIONS CALLED  :   frange_ran()                                 */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Tom Logan                                    */
/*                                                                              */
/*           DATE              :   9/15/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/



void find_live(cum_probab,live,pop_size,P)
VECTOR cum_probab; /*Cumulative probability*/
IVECTOR live;      /*Agents that are going to reproduce*/
int pop_size,      /*Population size*/
    P;             /*Total number of parents needed to reproduce*/
{
  float random;
  int count=0,/*Count of the number of agents chosen to live*/
      i;

  do
    {
      /*Choosing a random cumulative probability*/
      random = frange_ran(0.0,1.0);
      i=0;
      /*Finding the agent with the chosen cumulative probability*/
      do{
        i++;
        }while((random > cum_probab[i]) && (i< pop_size));

      /*Chosing the parent with that probability to reproduce*/
      if(count < P)
        {
          live[i]++;
          count++;
        }
    }while(count < P);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_die()                                   */
/*                                                                              */
/*           SYNOPSIS          :   void find_die(cum_probab,die,pop_size,P4+P5) */
/*                                                                              */
/*           DESCRIPTION       :   This function finds the agents from the      */
/*                                  population, who are going to die.            /
/*                                                                              */
/*           FUNCTIONS CALLED  :   frange_ran()                                 */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Tom Logan                                    */
/*                                                                              */
/*           DATE              :   9/15/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/



int find_die(cum_probab,die,pop_size)
VECTOR cum_probab; /*Cumulative probability*/
IVECTOR die;       /*Agents that are going to die*/
int pop_size;      /*Population size*/
{
  float random;
  int i;
  int done = FALSE;

  do
    {
      /*Choosing a random cumulative probability*/
      random = frange_ran(0.0,1.0);
      i=0;
      /*Finding the agent with the chosen cumulative probability*/
      do{
        i++;
        }
      while((random > cum_probab[i]) && (i< pop_size));

      /*Chosing the agent to die*/
      if ((die[pop_size+1-i] == 0) && (i < pop_size))
        done = TRUE;
    }
  while(!done);
  return(pop_size+1-i);
}

/********************************************************************************/
/*                                                                              */
/*           FUNCTION NAME     :   find_X()                                     */
/*                                                                              */
/*           SYNOPSIS          :   void find_X(final,agen.X,x2_vari,tot_eq,x1,  */
/*                                                                           x2)*/
/*                                                                              */
/*           DESCRIPTION       :   This function finds the value of all the     */
/*                                  variables in the original problem, with     */
/*                                  the values of the remaining variables.      */
/*                                                                              */
/*           FUNCTIONS CALLED  :   none                                         */
/*                                                                              */
/*           CALLING FUNCITONS :   optimization()                               */
/*                                                                              */
/*           AUTHOR            :   Swarnalatha Swaminathan                      */
/*                                                                              */
/*           DATE              :   1/17/92                                      */
/*                                                                              */
/*                                                                              */
/*           REV            DATE            BY           DESCRIPTION            */
/*           ---            ----            --           -----------            */
/*                                                                              */
/*                                                                              */
/********************************************************************************/



void find_X(final,agent,X,x2_vari,tot_eq,x1,x2,a1_b)
MATRIX final;
VECTOR agent,X,a1_b;
IVECTOR x1,x2;
int x2_vari,tot_eq;
{
  int i,j;

  for(j=1; j<=x2_vari; j++)
    X[x2[j]] = agent[j];

  for(j = 1; j<=tot_eq; j++)
    {
      X[x1[j]] = a1_b[j];
      for(i=1; i<=x2_vari; i++)
        X[x1[j]] = X[x1[j]] + agent[i] * final[j+x2_vari][i+1];
    }
}
